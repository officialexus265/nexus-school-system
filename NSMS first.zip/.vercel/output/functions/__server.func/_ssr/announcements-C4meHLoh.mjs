import { o as __toESM } from "../_runtime.mjs";
import { r as formatDate } from "./utils-CZhKFE8j.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useNexusSession } from "./session-Bq84HYht.mjs";
import { i as addAnnouncement, m as useSnapshot, p as useInvalidateSnapshot, t as PageHeader } from "./use-snapshot-DdgAICMx.mjs";
import { t as Skeleton } from "./skeleton-bYh8s0u6.mjs";
import { t as Button } from "./button-Bwm68GMl.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, s as DialogTrigger, t as Dialog } from "./dialog-d-86_FpX.mjs";
import { t as Input } from "./input-4PW7zVuz.mjs";
import { t as Label } from "./label-KhZwICj-.mjs";
import { t as Textarea } from "./textarea-Cfzqrv2O.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/announcements-C4meHLoh.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function NoticesPage() {
	const q = useSnapshot();
	const persona = useNexusSession((s) => s.persona);
	if (q.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	if (!q.data) return null;
	const snap = q.data;
	const dark = persona === "parent";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl text-foam",
			children: "Notices"
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-mist",
			children: "School-wide, class and individual messages."
		})] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Communication",
			title: "Notices",
			description: "Announcements, fee reminders and result alerts share the same engine.",
			actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Compose, { schoolId: snap.school.id })
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "mt-6 space-y-3",
			children: snap.announcements.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: dark ? "rounded-xl border border-foam/10 bg-ink-2 p-4" : "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: `text-[11px] uppercase tracking-[0.14em] ${dark ? "text-mist" : "text-muted-foreground"}`,
						children: [
							a.audience,
							" · ",
							a.author,
							" · ",
							formatDate(a.created_at)
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: `mt-1 font-display text-xl ${dark ? "text-foam" : ""}`,
						children: a.title
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: `mt-2 text-sm leading-relaxed ${dark ? "text-mist" : "text-muted-foreground"}`,
						children: a.body
					})
				]
			}, a.id))
		}),
		!dark ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl",
				children: "Notification log"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: snap.notifications.map((n) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						n.title,
						" · ",
						n.channel
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-xs text-muted-foreground",
						children: n.is_read ? "Read" : "Unread"
					})]
				}, n.id))
			})]
		}) : null
	] });
}
function Compose({ schoolId }) {
	const invalidate = useInvalidateSnapshot();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [title, setTitle] = (0, import_react.useState)("");
	const [body, setBody] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "New notice" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "New notice" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Title" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
						value: title,
						onChange: (e) => setTitle(e.target.value)
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "space-y-1.5",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Body" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
						value: body,
						onChange: (e) => setBody(e.target.value)
					})]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				disabled: busy || !title.trim() || !body.trim(),
				onClick: async () => {
					setBusy(true);
					try {
						await addAnnouncement({ data: {
							schoolId,
							title,
							body,
							audience: "ALL"
						} });
						toast.success("Posted");
						setOpen(false);
						setTitle("");
						setBody("");
						await invalidate();
					} catch (e) {
						toast.error(e instanceof Error ? e.message : "Failed");
					} finally {
						setBusy(false);
					}
				},
				children: "Publish notice"
			}) })
		] })]
	});
}
//#endregion
export { NoticesPage as component };
