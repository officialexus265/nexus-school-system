import { o as __toESM } from "../_runtime.mjs";
import { c as money, d as studentName, t as cn, u as pct } from "./utils-CZhKFE8j.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useNexusSession } from "./session-Bq84HYht.mjs";
import { m as useSnapshot, n as StatCard, t as PageHeader } from "./use-snapshot-DdgAICMx.mjs";
import { t as StatusPill } from "./status-pill-BHrU-BqV.mjs";
import { t as Skeleton } from "./skeleton-bYh8s0u6.mjs";
import { a as currentTerm, c as parentChildren, d as schoolOutstanding, f as studentAttendance, h as studentPosition, i as classLabel, l as publishedTerm, m as studentBalance, o as defaultParent, p as studentAverage, r as classById, s as defaultTeacher, t as attendanceRate, u as schoolCollected } from "./selectors-ZxoSqobI.mjs";
import { t as Button } from "./button-Bwm68GMl.mjs";
import { n as Root, t as Indicator } from "../_libs/radix-ui__react-progress.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/app-B_Ht3knY.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ParentHome({ snap }) {
	const parent = defaultParent(snap);
	const children = parent ? parentChildren(snap, parent.id) : [];
	const term = publishedTerm(snap);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-[11px] uppercase tracking-[0.16em] text-mist",
					children: "Good afternoon"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "mt-1 font-display text-3xl font-medium tracking-tight text-foam",
					children: parent?.full_name ?? "Parent"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1 text-sm text-mist",
					children: "Linked children are verified. Unpublished marks stay hidden."
				})
			] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3",
				children: children.map((child) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChildCard, {
					snap,
					student: child,
					termId: term?.id
				}, child.id))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl text-foam",
				children: "Notices"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-3",
				children: snap.announcements.slice(0, 3).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl border border-foam/10 bg-ink-2 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm font-medium text-foam",
						children: a.title
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-sm text-mist",
						children: a.body
					})]
				}, a.id))
			})] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: "/app/finance",
				className: "block rounded-xl border border-foam/10 bg-ink-2 p-4",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.16em] text-mist",
						children: "Household balance"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 font-display text-3xl tabular-nums text-foam",
						children: money(children.reduce((a, c) => a + studentBalance(snap, c.id), 0))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "mt-1 text-xs text-mist",
						children: "Open the payment centre"
					})
				]
			})
		]
	});
}
function ChildCard({ snap, student, termId }) {
	const avg = termId ? studentAverage(snap, student.id, termId, true) : null;
	const pos = termId ? studentPosition(snap, student.id, termId) : null;
	const att = studentAttendance(snap, student.id);
	const peers = snap.students.filter((s) => s.class_id === student.class_id).length;
	const tone = snap.behaviour.filter((b) => b.student_id === student.id).some((b) => b.kind === "NEGATIVE" && b.status === "OPEN") ? "Watch" : "Good";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl border border-foam/10 bg-ink-2 p-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between gap-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl text-foam",
					children: studentName(student)
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-mist",
					children: [
						classLabel(classById(snap, student.class_id)),
						" · ",
						student.admission_number
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: tone === "Good" ? "ACTIVE" : "OPEN" })]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("dl", {
				className: "mt-4 grid grid-cols-3 gap-3 text-center",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-[11px] uppercase tracking-wide text-mist",
						children: "Average"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-display text-2xl tabular-nums text-foam",
						children: avg != null ? pct(avg) : "—"
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-[11px] uppercase tracking-wide text-mist",
						children: "Attend."
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-display text-2xl tabular-nums text-foam",
						children: pct(att)
					})] }),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-[11px] uppercase tracking-wide text-mist",
						children: "Behaviour"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "mt-1 font-display text-2xl text-foam",
						children: tone
					})] })
				]
			}),
			pos ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-3 text-xs text-mist",
				children: [
					"Term 1 position ",
					pos,
					" of ",
					peers
				]
			}) : null
		]
	});
}
var Progress = import_react.forwardRef(({ className, value, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Root, {
	ref,
	className: cn("relative h-1.5 w-full overflow-hidden rounded-full bg-secondary", className),
	...props,
	children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Indicator, {
		className: "h-full bg-primary transition-[transform] duration-300 ease-[cubic-bezier(0.22,1,0.36,1)]",
		style: { transform: `translateX(-${100 - (value ?? 0)}%)` }
	})
}));
Progress.displayName = Root.displayName;
function AppHome() {
	const persona = useNexusSession((s) => s.persona);
	const q = useSnapshot();
	if (q.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DashSkeleton, {});
	if (q.error || !q.data) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-8 shadow-[var(--shadow-border)]",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-2xl",
				children: "Could not load the school desk."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 text-sm text-muted-foreground",
				children: q.error instanceof Error ? q.error.message : "Unknown error"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				className: "mt-4",
				onClick: () => q.refetch(),
				children: "Retry"
			})
		]
	});
	const snap = q.data;
	if (persona === "parent") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentHome, { snap });
	if (persona === "platform") return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		kicker: "Platform",
		title: "NEXUS control",
		description: "Activation, subscriptions and tenant health across the estate.",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/app/platform",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Open platform" })
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "grid gap-3 sm:grid-cols-3",
		children: snap.schools.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex items-start justify-between",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "font-display text-xl",
					children: s.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
					className: "text-xs text-muted-foreground",
					children: [
						s.city,
						" · ",
						s.subscription_plan
					]
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: s.status })]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "mt-4 text-sm text-muted-foreground",
				children: ["Activation ", money(s.activation_fee)]
			})]
		}, s.id))
	})] });
	if (persona === "teacher") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TeacherHome, { snap });
	if (persona === "bursar") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(BursarHome, { snap });
	if (persona === "exam") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ExamHome, { snap });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(OwnerHome, { snap });
}
function DashSkeleton() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "space-y-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-12 w-64" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "grid gap-3 md:grid-cols-4",
				children: Array.from({ length: 4 }).map((_, i) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-28" }, i))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" })
		]
	});
}
function OwnerHome({ snap }) {
	const term = currentTerm(snap);
	const today = snap.attendance.filter((a) => a.date === "2026-09-15");
	const present = attendanceRate(today);
	const pending = snap.submissions.filter((s) => s.status !== "PUBLISHED" && s.status !== "LOCKED");
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: snap.school.name,
			title: "Morning register",
			description: `${term?.name ?? "Term"} · 15 September 2026. ${snap.students.length} students on roll.`
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "On roll",
					value: String(snap.students.length),
					hint: `${snap.staff.filter((s) => s.role === "teacher").length} teachers`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Today's attendance",
					value: pct(present),
					hint: `${today.filter((a) => a.status === "PRESENT").length} present of ${today.length} marked`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Outstanding fees",
					value: money(schoolOutstanding(snap)),
					hint: `${money(schoolCollected(snap))} collected`
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Result packets",
					value: String(pending.length),
					hint: "Awaiting review or publish"
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4 lg:grid-cols-[1.3fr_0.7fr]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl font-medium",
						children: "Result pipeline"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: ["Form 2A · ", term?.name]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-4 space-y-3",
						children: snap.submissions.filter((s) => s.term_id === term?.id).map((s) => {
							const subj = snap.subjects.find((x) => x.id === s.subject_id);
							const cls = classById(snap, s.class_id);
							return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
								className: "flex items-center justify-between gap-3 border-b border-border py-2 last:border-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-sm font-medium",
									children: subj?.name
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
									className: "text-xs text-muted-foreground",
									children: classLabel(cls)
								})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: s.status })]
							}, s.id);
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
						to: "/app/results",
						className: "mt-3 inline-block text-sm text-primary hover:underline",
						children: "Open exam office"
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "font-display text-xl font-medium",
					children: "Ledger"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
					className: "mt-4 space-y-3",
					children: snap.audit.slice(0, 5).map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "border-b border-border pb-3 last:border-0",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm font-medium",
							children: a.action.replaceAll("_", " ")
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "text-xs text-muted-foreground",
							children: [
								a.actor,
								" · ",
								a.detail
							]
						})]
					}, a.id))
				})]
			})]
		})
	] });
}
function TeacherHome({ snap }) {
	const teacher = defaultTeacher(snap);
	const mine = snap.assignments.filter((a) => a.staff_id === teacher?.id);
	const classIds = [...new Set(mine.map((a) => a.class_id))];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Teacher",
			title: teacher?.full_name ?? "Teacher",
			description: "Assigned classes and the Mathematics desk."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Classes",
					value: String(classIds.length)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Subjects",
					value: String(new Set(mine.map((a) => a.subject_id)).size)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Open assessments",
					value: String(snap.assessments.filter((a) => a.staff_id === teacher?.id).length)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl",
				children: "Assignments"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-border",
				children: mine.map((a) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex items-center justify-between py-3 text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						classLabel(classById(snap, a.class_id)),
						" ·",
						" ",
						snap.subjects.find((s) => s.id === a.subject_id)?.name
					] }), a.is_class_teacher ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: "VERIFIED" }) : null]
				}, a.id))
			})]
		})
	] });
}
function BursarHome({ snap }) {
	const outstanding = schoolOutstanding(snap);
	const collected = schoolCollected(snap);
	const total = outstanding + collected;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Bursar",
			title: "Term 2 collection",
			description: "Verified payments only. A frontend success message is never enough."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Collected",
					value: money(collected)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Outstanding",
					value: money(outstanding)
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Receipts",
					value: String(snap.payments.length)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Collection"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums text-sm",
						children: pct(total ? collected / total * 100 : 0)
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Progress, {
					className: "mt-3",
					value: total ? collected / total * 100 : 0
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/app/finance",
					className: "mt-4 inline-block text-sm text-primary hover:underline",
					children: "Open the ledger"
				})
			]
		})
	] });
}
function ExamHome({ snap }) {
	const term = currentTerm(snap);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		kicker: "Examination office",
		title: "Packets in flight",
		description: "Nothing reaches a parent until you approve and an authorised publisher confirms.",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
			to: "/app/results",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Review packets" })
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
			className: "divide-y divide-border",
			children: snap.submissions.filter((s) => s.term_id === term?.id).map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
				className: "flex items-center justify-between py-3",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm font-medium",
					children: snap.subjects.find((x) => x.id === s.subject_id)?.name
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-xs text-muted-foreground",
					children: classLabel(classById(snap, s.class_id))
				})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: s.status })]
			}, s.id))
		})
	})] });
}
//#endregion
export { AppHome as component };
