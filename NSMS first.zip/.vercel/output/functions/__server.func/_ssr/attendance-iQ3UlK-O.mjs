import { d as studentName } from "./utils-CZhKFE8j.mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useNexusSession } from "./session-Bq84HYht.mjs";
import { c as markAttendance, m as useSnapshot, p as useInvalidateSnapshot, t as PageHeader } from "./use-snapshot-DdgAICMx.mjs";
import { t as StatusPill } from "./status-pill-BHrU-BqV.mjs";
import { t as Skeleton } from "./skeleton-bYh8s0u6.mjs";
import { c as parentChildren, g as todayIso, i as classLabel, o as defaultParent, r as classById, t as attendanceRate } from "./selectors-ZxoSqobI.mjs";
import { t as Button } from "./button-Bwm68GMl.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/attendance-iQ3UlK-O.js
var import_jsx_runtime = require_jsx_runtime();
var STATUSES = [
	"PRESENT",
	"ABSENT",
	"LATE",
	"EXCUSED"
];
function AttendancePage() {
	const q = useSnapshot();
	const invalidate = useInvalidateSnapshot();
	const persona = useNexusSession((s) => s.persona);
	if (q.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	if (!q.data) return null;
	const snap = q.data;
	const date = todayIso();
	if (persona === "parent") {
		const parent = defaultParent(snap);
		const children = parent ? parentChildren(snap, parent.id) : [];
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl text-foam",
				children: "Attendance"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-mist",
				children: "Absence alerts go to verified phones when the school policy says so."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-6 space-y-4",
				children: children.map((c) => {
					const rows = snap.attendance.filter((a) => a.student_id === c.id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "rounded-xl border border-foam/10 bg-ink-2 p-4",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-xl text-foam",
								children: studentName(c)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
								className: "tabular-nums text-sm text-mist",
								children: [attendanceRate(rows), "%"]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mt-3 flex flex-wrap gap-1.5",
							children: rows.slice().reverse().map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								title: `${r.date} ${r.status}`,
								className: r.status === "PRESENT" ? "grid size-7 place-items-center rounded-sm bg-ok/40 text-[10px] text-foam" : r.status === "ABSENT" ? "grid size-7 place-items-center rounded-sm bg-destructive/40 text-[10px] text-foam" : "grid size-7 place-items-center rounded-sm bg-warn/40 text-[10px] text-foam",
								children: r.status[0]
							}, r.id))
						})]
					}, c.id);
				})
			})
		] });
	}
	const classId = snap.classes.find((c) => c.name === "Form 2" && c.stream === "A")?.id ?? snap.classes[0]?.id;
	const roster = snap.students.filter((s) => s.class_id === classId);
	async function setStatus(student, status) {
		try {
			await markAttendance({ data: {
				studentId: student.id,
				date,
				status,
				classId: student.class_id ?? void 0
			} });
			toast.success(`${studentName(student)} · ${status.toLowerCase()}`);
			await invalidate();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "Could not save");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Register",
			title: `${classLabel(classById(snap, classId))} · today`,
			description: "15 September 2026. Changing a mark writes the register immediately."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-2",
			children: roster.map((s) => {
				const row = snap.attendance.find((a) => a.student_id === s.id && a.date === date);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-col gap-3 rounded-xl bg-card p-4 shadow-[var(--shadow-border)] sm:flex-row sm:items-center sm:justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: studentName(s)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs text-muted-foreground",
						children: s.admission_number
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: STATUSES.map((st) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
							size: "sm",
							variant: row?.status === st ? "default" : "outline",
							onClick: () => setStatus(s, st),
							children: st.slice(0, 1) + st.slice(1).toLowerCase()
						}, st))
					})]
				}, s.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl",
				children: "Recent absences"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: snap.attendance.filter((a) => a.status === "ABSENT").slice(0, 5).map((a) => {
					const s = snap.students.find((x) => x.id === a.student_id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex items-center justify-between text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							s ? studentName(s) : "Student",
							" · ",
							a.date
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: "ABSENT" })]
					}, a.id);
				})
			})]
		})
	] });
}
//#endregion
export { AttendancePage as component };
