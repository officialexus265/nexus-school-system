import { s as initials, t as cn } from "./utils-CZhKFE8j.mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/avatar-kowjRr3_.js
var import_jsx_runtime = require_jsx_runtime();
function Avatar({ name, className, tone = "paper" }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: cn("inline-flex size-8 shrink-0 items-center justify-center rounded-full text-xs font-medium", tone === "ink" && "bg-ink text-foam", tone === "teal" && "bg-primary text-primary-foreground", tone === "paper" && "bg-secondary text-foreground", className),
		children: initials(name)
	});
}
//#endregion
export { Avatar as t };
