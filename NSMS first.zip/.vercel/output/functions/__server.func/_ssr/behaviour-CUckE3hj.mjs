import { o as __toESM } from "../_runtime.mjs";
import { d as studentName, r as formatDate } from "./utils-CZhKFE8j.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useNexusSession } from "./session-Bq84HYht.mjs";
import { a as addBehaviour, m as useSnapshot, p as useInvalidateSnapshot, t as PageHeader } from "./use-snapshot-DdgAICMx.mjs";
import { t as StatusPill } from "./status-pill-BHrU-BqV.mjs";
import { t as Skeleton } from "./skeleton-bYh8s0u6.mjs";
import { c as parentChildren, o as defaultParent } from "./selectors-ZxoSqobI.mjs";
import { t as Button } from "./button-Bwm68GMl.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, s as DialogTrigger, t as Dialog } from "./dialog-d-86_FpX.mjs";
import { t as Input } from "./input-4PW7zVuz.mjs";
import { t as Label } from "./label-KhZwICj-.mjs";
import { t as Textarea } from "./textarea-Cfzqrv2O.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BqmBkL4p.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/behaviour-CUckE3hj.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function BehaviourPage() {
	const q = useSnapshot();
	const persona = useNexusSession((s) => s.persona);
	if (q.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	if (!q.data) return null;
	const snap = q.data;
	if (persona === "parent") {
		const parent = defaultParent(snap);
		const ids = new Set((parent ? parentChildren(snap, parent.id) : []).map((c) => c.id));
		const rows = snap.behaviour.filter((b) => ids.has(b.student_id));
		return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
				className: "font-display text-3xl text-foam",
				children: "Behaviour"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-sm text-mist",
				children: "The school chooses which incidents parents can see."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-6 space-y-3",
				children: rows.map((b) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "rounded-xl border border-foam/10 bg-ink-2 p-4",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "flex items-center justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-sm font-medium text-foam",
								children: b.category
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: b.kind })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "mt-1 text-sm text-mist",
							children: b.description
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "mt-2 text-xs text-mist",
							children: [
								(() => {
									const st = snap.students.find((s) => s.id === b.student_id);
									return st ? studentName(st) : "Student";
								})(),
								" ",
								"· ",
								formatDate(b.date)
							]
						})
					]
				}, b.id))
			})
		] });
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
		kicker: "Pastoral",
		title: "Behaviour",
		description: "Positive and negative records, with points and an auditable case trail.",
		actions: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RecordIncident, { students: snap.students })
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "space-y-3",
		children: snap.behaviour.map((b) => {
			const s = snap.students.find((x) => x.id === b.student_id);
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("article", {
				className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex flex-wrap items-start justify-between gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-medium",
						children: s ? studentName(s) : "Student"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
						className: "text-sm text-muted-foreground",
						children: [
							b.category,
							" · ",
							formatDate(b.date),
							" · ",
							b.recorded_by
						]
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: b.kind }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: "tabular-nums text-sm",
							children: b.points > 0 ? `+${b.points}` : b.points
						})]
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm",
					children: b.description
				})]
			}, b.id);
		})
	})] });
}
function RecordIncident({ students }) {
	const invalidate = useInvalidateSnapshot();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [studentId, setStudent] = (0, import_react.useState)(students[0]?.id ?? "");
	const [kind, setKind] = (0, import_react.useState)("NEGATIVE");
	const [category, setCategory] = (0, import_react.useState)("Punctuality");
	const [description, setDesc] = (0, import_react.useState)("");
	const [points, setPoints] = (0, import_react.useState)("-2");
	const [busy, setBusy] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Record incident" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Record incident" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Student" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: studentId,
							onValueChange: setStudent,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: students.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectItem, {
								value: s.id,
								children: [
									s.first_name,
									" ",
									s.last_name
								]
							}, s.id)) })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid gap-3 sm:grid-cols-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Kind" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
								value: kind,
								onValueChange: (v) => setKind(v),
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "POSITIVE",
									children: "Positive"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "NEGATIVE",
									children: "Negative"
								})] })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "space-y-1.5",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Points" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
								value: points,
								onChange: (e) => setPoints(e.target.value)
							})]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Category" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: category,
							onChange: (e) => setCategory(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Description" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Textarea, {
							value: description,
							onChange: (e) => setDesc(e.target.value)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				disabled: busy || !description.trim(),
				onClick: async () => {
					setBusy(true);
					try {
						await addBehaviour({ data: {
							studentId,
							category,
							kind,
							description,
							points: Number(points) || 0
						} });
						toast.success("Incident recorded");
						setOpen(false);
						setDesc("");
						await invalidate();
					} catch (e) {
						toast.error(e instanceof Error ? e.message : "Failed");
					} finally {
						setBusy(false);
					}
				},
				children: "Save"
			}) })
		] })]
	});
}
//#endregion
export { BehaviourPage as component };
