import { o as __toESM } from "../_runtime.mjs";
import { c as money, d as studentName, r as formatDate } from "./utils-CZhKFE8j.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useNexusSession } from "./session-Bq84HYht.mjs";
import { m as useSnapshot, n as StatCard, p as useInvalidateSnapshot, t as PageHeader, u as recordPayment } from "./use-snapshot-DdgAICMx.mjs";
import { t as StatusPill } from "./status-pill-BHrU-BqV.mjs";
import { t as Skeleton } from "./skeleton-bYh8s0u6.mjs";
import { c as parentChildren, d as schoolOutstanding, m as studentBalance, n as chargeBalance, o as defaultParent, u as schoolCollected } from "./selectors-ZxoSqobI.mjs";
import { t as Button } from "./button-Bwm68GMl.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, t as Dialog } from "./dialog-d-86_FpX.mjs";
import { t as Input } from "./input-4PW7zVuz.mjs";
import { t as Label } from "./label-KhZwICj-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BqmBkL4p.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/finance-0wOLUvWs.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function FinancePage() {
	const q = useSnapshot();
	const persona = useNexusSession((s) => s.persona);
	if (q.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-80" });
	if (!q.data) return null;
	if (persona === "parent") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentFees, { snap: q.data });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaffFinance, { snap: q.data });
}
function StaffFinance({ snap }) {
	const [charge, setCharge] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Bursar",
			title: "Fees & payments",
			description: "Transactions are verified, allocated and receipted. Use void or reverse — never delete."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-3",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Collected",
					value: money(schoolCollected(snap))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Outstanding",
					value: money(schoolOutstanding(snap))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatCard, {
					label: "Receipts this term",
					value: String(snap.payments.length)
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl",
				children: "Student charges"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "mt-3 overflow-x-auto",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
					className: "w-full min-w-[640px] text-left text-sm",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
						className: "text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Student"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Item"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Due"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Paid"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
								className: "py-2 font-medium",
								children: "Balance"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", { className: "py-2 font-medium" })
						] })
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: snap.charges.map((c) => {
						const s = snap.students.find((x) => x.id === c.student_id);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
							className: "border-t border-border",
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2",
									children: s ? studentName(s) : "—"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2",
									children: c.description
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 tabular-nums",
									children: money(c.amount)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 tabular-nums",
									children: money(c.paid)
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: c.status })
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
									className: "py-2 text-right",
									children: chargeBalance(c) > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
										size: "sm",
										variant: "outline",
										onClick: () => setCharge(c),
										children: "Record"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "text-xs text-muted-foreground",
										children: "Settled"
									})
								})
							]
						}, c.id);
					}) })]
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-4 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl",
				children: "Receipts"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 divide-y divide-border",
				children: snap.payments.map((p) => {
					const s = snap.students.find((x) => x.id === p.student_id);
					return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
						className: "flex flex-wrap items-center justify-between gap-2 py-2 text-sm",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
							p.receipt_number,
							" · ",
							s ? studentName(s) : "",
							" · ",
							p.method
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
							className: "tabular-nums",
							children: [
								money(p.amount),
								" · ",
								formatDate(p.payment_date)
							]
						})]
					}, p.id);
				})
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayDialog, {
			charge,
			onClose: () => setCharge(null)
		})
	] });
}
function PayDialog({ charge, onClose }) {
	const invalidate = useInvalidateSnapshot();
	const [amount, setAmount] = (0, import_react.useState)("");
	const [method, setMethod] = (0, import_react.useState)("Cash");
	const [ref, setRef] = (0, import_react.useState)("");
	const [busy, setBusy] = (0, import_react.useState)(false);
	const due = charge ? chargeBalance(charge) : 0;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
		open: !!charge,
		onOpenChange: (o) => !o && onClose(),
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogHeader, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Record payment" }) }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
				className: "text-sm text-muted-foreground",
				children: [
					charge?.description,
					" · outstanding ",
					money(due)
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "space-y-3",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Amount (MK)" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: amount,
							onChange: (e) => setAmount(e.target.value),
							placeholder: String(due)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Method" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: method,
							onValueChange: setMethod,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "Cash",
									children: "Cash"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "Airtel Money",
									children: "Airtel Money"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
									value: "Bank transfer",
									children: "Bank transfer"
								})
							] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Reference" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: ref,
							onChange: (e) => setRef(e.target.value)
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				variant: "outline",
				onClick: onClose,
				children: "Cancel"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				disabled: busy || !charge,
				onClick: async () => {
					if (!charge) return;
					setBusy(true);
					try {
						const res = await recordPayment({ data: {
							chargeId: charge.id,
							amount: Number(amount) || due,
							method,
							reference: ref || void 0
						} });
						toast.success(`Receipt ${res.receipt}`);
						onClose();
						await invalidate();
					} catch (e) {
						toast.error(e instanceof Error ? e.message : "Payment failed");
					} finally {
						setBusy(false);
					}
				},
				children: "Verify & receipt"
			})] })
		] })
	});
}
function ParentFees({ snap }) {
	const parent = defaultParent(snap);
	const children = parent ? parentChildren(snap, parent.id) : [];
	const [charge, setCharge] = (0, import_react.useState)(null);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl text-foam",
			children: "Payment centre"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-mist",
			children: "Choose a charge, pay, and keep the receipt."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 space-y-4",
			children: children.map((c) => {
				const charges = snap.charges.filter((x) => x.student_id === c.id);
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl border border-foam/10 bg-ink-2 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-xl text-foam",
							children: studentName(c)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "tabular-nums text-sm text-mist",
							children: [money(studentBalance(snap, c.id)), " due"]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 divide-y divide-foam/10",
						children: charges.map((ch) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between py-2 text-sm text-foam",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [ch.description, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "ml-2 text-mist",
								children: [
									money(ch.paid),
									" / ",
									money(ch.amount)
								]
							})] }), chargeBalance(ch) > 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								size: "sm",
								className: "bg-foam text-ink hover:bg-foam/90",
								onClick: () => setCharge(ch),
								children: "Pay"
							}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: "PAID" })]
						}, ch.id))
					})]
				}, c.id);
			})
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-6",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl text-foam",
				children: "Receipts"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
				className: "mt-3 space-y-2",
				children: snap.payments.filter((p) => children.some((c) => c.id === p.student_id)).map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
					className: "flex justify-between rounded-xl border border-foam/10 px-4 py-3 text-sm text-foam",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
						p.receipt_number,
						" · ",
						p.method
					] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "tabular-nums",
						children: money(p.amount)
					})]
				}, p.id))
			})]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PayDialog, {
			charge,
			onClose: () => setCharge(null)
		})
	] });
}
//#endregion
export { FinancePage as component };
