import { v as Link, y as Navigate } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Skeleton } from "./skeleton-bYh8s0u6.mjs";
import { t as Button } from "./button-Bwm68GMl.mjs";
import { r as signIn } from "./client-B40BzJxt.mjs";
import { t as GROK_PROVIDERS } from "./server-fysoyq1j.mjs";
import { i as useCurrentUserState, t as NexusMark } from "./use-current-user-DFJztN0m.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/login-C5xmZD85.js
var import_jsx_runtime = require_jsx_runtime();
function Login() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
		className: "grid min-h-dvh place-items-center bg-ink",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-48 w-80 bg-ink-3" })
	});
	if (user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Navigate, { to: "/app" });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
		className: "relative min-h-dvh bg-ink text-foam",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ledger-grid pointer-events-none absolute inset-0 opacity-40" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "relative mx-auto flex min-h-dvh max-w-md flex-col justify-center px-6 py-16",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "mb-10 flex items-center gap-2 text-foam",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NexusMark, { className: "text-foam" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-2xl font-medium tracking-tight",
						children: "NEXUS"
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-4xl font-medium tracking-tight",
					children: "Enter the desk."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 text-sm leading-relaxed text-mist",
					children: "School owners, teachers and platform operators sign in here. Parents use the same workspace after you switch role inside."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mt-8 space-y-3",
					children: GROK_PROVIDERS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
						type: "button",
						variant: "secondary",
						className: "h-11 w-full bg-foam text-ink hover:bg-foam/90",
						onClick: () => signIn(p.providerId, { callbackURL: "/app" }),
						children: ["Continue with ", p.label]
					}, p.providerId))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-8 text-xs text-mist",
					children: "Opening the workspace provisions Sunrise Academy with live Term 2 records for this account only."
				})
			]
		})]
	});
}
//#endregion
export { Login as component };
