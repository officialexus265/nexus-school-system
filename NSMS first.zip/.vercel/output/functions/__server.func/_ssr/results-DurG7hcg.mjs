import { o as __toESM } from "../_runtime.mjs";
import { d as studentName, l as num, u as pct } from "./utils-CZhKFE8j.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useNexusSession } from "./session-Bq84HYht.mjs";
import { d as saveMarks, l as publishResults, m as useSnapshot, p as useInvalidateSnapshot, s as advanceSubmission, t as PageHeader } from "./use-snapshot-DdgAICMx.mjs";
import { t as StatusPill } from "./status-pill-BHrU-BqV.mjs";
import { t as Skeleton } from "./skeleton-bYh8s0u6.mjs";
import { a as currentTerm, c as parentChildren, h as studentPosition, i as classLabel, l as publishedTerm, o as defaultParent, p as studentAverage } from "./selectors-ZxoSqobI.mjs";
import { t as Button } from "./button-Bwm68GMl.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, t as Dialog } from "./dialog-d-86_FpX.mjs";
import { t as Input } from "./input-4PW7zVuz.mjs";
import { n as toast } from "../_libs/sonner.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/results-DurG7hcg.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function ResultsPage() {
	const q = useSnapshot();
	const persona = useNexusSession((s) => s.persona);
	if (q.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-80" });
	if (!q.data) return null;
	if (persona === "parent") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentResults, { snap: q.data });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StaffResults, {
		snap: q.data,
		persona
	});
}
function ParentResults({ snap }) {
	const parent = defaultParent(snap);
	const children = parent ? parentChildren(snap, parent.id) : [];
	const term = publishedTerm(snap);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
			className: "font-display text-3xl text-foam",
			children: "Published results"
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 text-sm text-mist",
			children: "Only packets the school has confirmed appear here. Term 2 is still inside the office."
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-6 space-y-5",
			children: children.map((c) => {
				const rows = term ? snap.results.filter((r) => r.student_id === c.id && r.term_id === term.id && r.status === "PUBLISHED") : [];
				const avg = term ? studentAverage(snap, c.id, term.id, true) : null;
				const pos = term ? studentPosition(snap, c.id, term.id) : null;
				const peers = snap.students.filter((s) => s.class_id === c.class_id).length;
				return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl border border-foam/10 bg-ink-2 p-4",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-baseline justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "font-display text-2xl text-foam",
							children: studentName(c)
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("p", {
							className: "tabular-nums text-sm text-mist",
							children: [avg != null ? pct(avg) : "—", pos ? ` · ${pos}/${peers}` : ""]
						})]
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 divide-y divide-foam/10",
						children: [rows.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between py-2 text-sm text-foam",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: snap.subjects.find((s) => s.id === r.subject_id)?.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums",
								children: [
									num(r.overall_score),
									"% ",
									r.grade
								]
							})]
						}, r.id)), rows.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: "py-2 text-sm text-mist",
							children: "Nothing published for this child."
						}) : null]
					})]
				}, c.id);
			})
		})
	] });
}
function StaffResults({ snap, persona }) {
	const invalidate = useInvalidateSnapshot();
	const term = currentTerm(snap);
	const published = publishedTerm(snap);
	const f2a = snap.classes.find((c) => c.name === "Form 2" && c.stream === "A");
	const packets = snap.submissions.filter((s) => s.class_id === f2a?.id && s.term_id === term?.id);
	const [confirm, setConfirm] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(false);
	const allReady = packets.every((p) => p.status === "APPROVED" || p.status === "READY_TO_PUBLISH" || p.status === "PUBLISHED");
	const already = packets.every((p) => p.status === "PUBLISHED");
	async function act(sub, action) {
		try {
			const res = await advanceSubmission({ data: {
				submissionId: sub.id,
				action
			} });
			toast.success(`Now ${res.status.replaceAll("_", " ").toLowerCase()}`);
			await invalidate();
		} catch (e) {
			toast.error(e instanceof Error ? e.message : "Could not update");
		}
	}
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "Examination office",
			title: `${classLabel(f2a)} · ${term?.name}`,
			description: "Draft marks are invisible to parents. Publication is a separate, auditable action.",
			actions: persona !== "teacher" ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				disabled: !allReady || already,
				onClick: () => setConfirm(true),
				children: already ? "Published" : "Publish…"
			}) : null
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "space-y-4",
			children: packets.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PacketCard, {
				snap,
				packet: p,
				onAct: act,
				persona,
				onSaved: invalidate
			}, p.id))
		}),
		published && f2a ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
			className: "mt-8 rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
				className: "font-display text-xl",
				children: ["Published · ", published.name]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ClassTable, {
				snap,
				classId: f2a.id,
				termId: published.id,
				onlyPublished: true
			})]
		}) : null,
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Dialog, {
			open: confirm,
			onOpenChange: setConfirm,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Publish results" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogDescription, { children: [
					"Academic year 2026 · ",
					term?.name,
					" · ",
					classLabel(f2a),
					" · ",
					snap.students.filter((s) => s.class_id === f2a?.id).length,
					" students."
				] })] }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "text-sm text-muted-foreground",
					children: "Published results will become visible to authorised parents. The publisher, time and class are written to the audit log."
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogFooter, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					variant: "outline",
					onClick: () => setConfirm(false),
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					disabled: busy,
					onClick: async () => {
						if (!f2a || !term) return;
						setBusy(true);
						try {
							const res = await publishResults({ data: {
								classId: f2a.id,
								termId: term.id,
								actor: "Mrs. Grace Mvula"
							} });
							toast.success(`Published for ${res.students} students`);
							setConfirm(false);
							await invalidate();
						} catch (e) {
							toast.error(e instanceof Error ? e.message : "Cannot publish yet");
						} finally {
							setBusy(false);
						}
					},
					children: "Confirm & publish"
				})] })
			] })
		})
	] });
}
function PacketCard({ snap, packet, onAct, persona, onSaved }) {
	const subject = snap.subjects.find((s) => s.id === packet.subject_id);
	const roster = snap.students.filter((s) => s.class_id === packet.class_id);
	const canEdit = packet.status === "DRAFT" || packet.status === "RETURNED";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
		className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex flex-col gap-2 sm:flex-row sm:items-center sm:justify-between",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
				className: "font-display text-xl",
				children: subject?.name
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-xs text-muted-foreground",
				children: "Continuous 40% · Examination 60%"
			})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "flex flex-wrap items-center gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: packet.status }),
					canEdit && (persona === "teacher" || persona === "owner") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => onAct(packet, "submit"),
						children: "Submit"
					}) : null,
					packet.status === "SUBMITTED" && persona !== "teacher" ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						variant: "outline",
						onClick: () => onAct(packet, "return"),
						children: "Return"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => onAct(packet, "verify"),
						children: "Verify"
					})] }) : null,
					packet.status === "VERIFIED" && (persona === "head" || persona === "owner" || persona === "exam") ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
						size: "sm",
						onClick: () => onAct(packet, "approve"),
						children: "Approve"
					}) : null
				]
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "mt-4 overflow-x-auto",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[520px] text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 font-medium",
							children: "Student"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 font-medium",
							children: "CA"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 font-medium",
							children: "Exam"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 font-medium",
							children: "Overall"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "py-2 font-medium",
							children: "Grade"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: roster.map((st) => {
					const r = snap.results.find((x) => x.student_id === st.id && x.subject_id === packet.subject_id && x.term_id === packet.term_id);
					if (!r) return null;
					return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(MarkRow, {
						name: studentName(st),
						resultId: r.id,
						ca: num(r.continuous_score),
						exam: num(r.exam_score),
						overall: num(r.overall_score),
						grade: r.grade ?? "—",
						editable: canEdit && (persona === "teacher" || persona === "owner"),
						onSaved
					}, st.id);
				}) })]
			})
		})]
	});
}
function MarkRow({ name, resultId, ca, exam, overall, grade, editable, onSaved }) {
	const [c, setC] = (0, import_react.useState)(String(ca));
	const [e, setE] = (0, import_react.useState)(String(exam));
	const dirty = (0, import_react.useMemo)(() => Number(c) !== ca || Number(e) !== exam, [
		c,
		e,
		ca,
		exam
	]);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
		className: "border-t border-border",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-2",
				children: name
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-2",
				children: editable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-8 w-16",
					value: c,
					onChange: (ev) => setC(ev.target.value)
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: ca
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-2",
				children: editable ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
					className: "h-8 w-16",
					value: e,
					onChange: (ev) => setE(ev.target.value)
				}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "tabular-nums",
					children: exam
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
				className: "py-2 tabular-nums",
				children: overall
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("td", {
				className: "py-2",
				children: [grade, editable && dirty ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
					size: "sm",
					variant: "ghost",
					className: "ml-2",
					onClick: async () => {
						await saveMarks({ data: {
							resultId,
							continuous: Number(c),
							exam: Number(e)
						} });
						toast.success("Saved");
						onSaved();
					},
					children: "Save"
				}) : null]
			})
		]
	});
}
function ClassTable({ snap, classId, termId, onlyPublished }) {
	const roster = snap.students.filter((s) => s.class_id === classId);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: "mt-3 overflow-x-auto",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
			className: "w-full min-w-[480px] text-left text-sm",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
				className: "text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 font-medium",
						children: "Student"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 font-medium",
						children: "Average"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
						className: "py-2 font-medium",
						children: "Position"
					})
				] })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: roster.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
				className: "border-t border-border",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-2",
						children: studentName(s)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-2 tabular-nums",
						children: pct(studentAverage(snap, s.id, termId, onlyPublished) ?? 0)
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
						className: "py-2 tabular-nums",
						children: studentPosition(snap, s.id, termId) ?? "—"
					})
				]
			}, s.id)) })]
		})
	});
}
//#endregion
export { ResultsPage as component };
