import { o as __toESM } from "../_runtime.mjs";
import { t as cn } from "./utils-CZhKFE8j.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { d as useRouterState, m as Outlet, v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useNexusSession, t as PERSONAS } from "./session-Bq84HYht.mjs";
import { t as Skeleton } from "./skeleton-bYh8s0u6.mjs";
import { t as Button } from "./button-Bwm68GMl.mjs";
import { _ as BookOpen, a as Shield, c as Megaphone, d as ClipboardCheck, f as ChevronRight, g as Building2, h as CalendarDays, l as LayoutDashboard, m as Check, n as Wallet, o as Settings, r as Users, s as Menu, t as X, u as GraduationCap, v as Bell } from "../_libs/lucide-react.mjs";
import { a as DialogOverlay, c as DialogTrigger, n as DialogClose, o as DialogPortal, r as DialogContent, s as DialogTitle, t as Dialog } from "../_libs/@radix-ui/react-dialog+[...].mjs";
import { a as Label2, c as Separator2, d as Trigger, i as ItemIndicator2, l as SubContent2, n as Content2, o as Portal2, r as Item2, s as Root2, t as CheckboxItem2, u as SubTrigger2 } from "../_libs/@radix-ui/react-dropdown-menu+[...].mjs";
import { i as useCurrentUserState, n as NexusWordmark, r as useCurrentUser } from "./use-current-user-DFJztN0m.mjs";
import { t as Avatar } from "./avatar-kowjRr3_.mjs";
import { i as UserButton, t as RedirectToSignIn } from "./gates-B2xIAI7e.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/route-Ufg2i7-k.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var DropdownMenu = Root2;
var DropdownMenuTrigger = Trigger;
var DropdownMenuSubTrigger = import_react.forwardRef(({ className, inset, children, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SubTrigger2, {
	ref,
	className: cn("flex cursor-pointer select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none focus:bg-accent data-[state=open]:bg-accent", inset && "pl-8", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ChevronRight, { className: "ml-auto size-4" })]
}));
DropdownMenuSubTrigger.displayName = SubTrigger2.displayName;
var DropdownMenuSubContent = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SubContent2, {
	ref,
	className: cn("z-50 min-w-32 overflow-hidden rounded-lg bg-popover p-1 text-popover-foreground shadow-[var(--shadow-lift)]", className),
	...props
}));
DropdownMenuSubContent.displayName = SubContent2.displayName;
var DropdownMenuContent = import_react.forwardRef(({ className, sideOffset = 6, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Portal2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Content2, {
	ref,
	sideOffset,
	className: cn("z-50 min-w-44 overflow-hidden rounded-lg bg-popover p-1 text-popover-foreground shadow-[var(--shadow-lift)]", className),
	...props
}) }));
DropdownMenuContent.displayName = Content2.displayName;
var DropdownMenuItem = import_react.forwardRef(({ className, inset, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Item2, {
	ref,
	className: cn("relative flex cursor-pointer select-none items-center gap-2 rounded-sm px-2 py-1.5 text-sm outline-none transition-colors focus:bg-accent focus:text-accent-foreground data-disabled:pointer-events-none data-disabled:opacity-50", inset && "pl-8", className),
	...props
}));
DropdownMenuItem.displayName = Item2.displayName;
var DropdownMenuCheckboxItem = import_react.forwardRef(({ className, children, checked, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(CheckboxItem2, {
	ref,
	className: cn("relative flex cursor-pointer select-none items-center rounded-sm py-1.5 pl-8 pr-2 text-sm outline-none transition-colors focus:bg-accent", className),
	checked,
	...props,
	children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
		className: "absolute left-2 flex size-3.5 items-center justify-center",
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ItemIndicator2, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Check, { className: "size-4" }) })
	}), children]
}));
DropdownMenuCheckboxItem.displayName = CheckboxItem2.displayName;
var DropdownMenuLabel = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label2, {
	ref,
	className: cn("px-2 py-1.5 text-xs font-medium text-muted-foreground", className),
	...props
}));
DropdownMenuLabel.displayName = Label2.displayName;
var DropdownMenuSeparator = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Separator2, {
	ref,
	className: cn("-mx-1 my-1 h-px bg-border", className),
	...props
}));
DropdownMenuSeparator.displayName = Separator2.displayName;
var Sheet = Dialog;
var SheetTrigger = DialogTrigger;
var SheetPortal = DialogPortal;
var SheetOverlay = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogOverlay, {
	ref,
	className: cn("fixed inset-0 z-50 bg-ink/40", className),
	...props
}));
SheetOverlay.displayName = DialogOverlay.displayName;
var SheetContent = import_react.forwardRef(({ className, children, side = "left", ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetPortal, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetOverlay, {}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, {
	ref,
	className: cn("fixed z-50 flex h-full flex-col bg-paper p-5 shadow-[var(--shadow-lift)]", side === "left" ? "left-0 top-0 w-72" : "right-0 top-0 w-80", className),
	...props,
	children: [children, /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogClose, {
		className: "absolute right-4 top-4 rounded-sm opacity-70 hover:opacity-100",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "sr-only",
			children: "Close"
		})]
	})]
})] }));
SheetContent.displayName = DialogContent.displayName;
var SheetHeader = ({ className, ...props }) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
	className: cn("mb-4 flex flex-col gap-1", className),
	...props
});
var SheetTitle = import_react.forwardRef(({ className, ...props }, ref) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, {
	ref,
	className: cn("font-display text-lg font-medium", className),
	...props
}));
SheetTitle.displayName = DialogTitle.displayName;
var OWNER_NAV = [
	{
		to: "/app",
		label: "Overview",
		icon: LayoutDashboard
	},
	{
		to: "/app/students",
		label: "Students",
		icon: GraduationCap
	},
	{
		to: "/app/people",
		label: "Staff & parents",
		icon: Users
	},
	{
		to: "/app/academics",
		label: "Academics",
		icon: BookOpen
	},
	{
		to: "/app/attendance",
		label: "Attendance",
		icon: CalendarDays
	},
	{
		to: "/app/results",
		label: "Results",
		icon: ClipboardCheck
	},
	{
		to: "/app/behaviour",
		label: "Behaviour",
		icon: Shield
	},
	{
		to: "/app/finance",
		label: "Finance",
		icon: Wallet
	},
	{
		to: "/app/announcements",
		label: "Notices",
		icon: Megaphone
	},
	{
		to: "/app/settings",
		label: "School",
		icon: Settings
	}
];
var NAV_BY_PERSONA = {
	owner: OWNER_NAV,
	head: OWNER_NAV.filter((i) => i.to !== "/app/settings"),
	teacher: [
		{
			to: "/app",
			label: "My classes",
			icon: LayoutDashboard
		},
		{
			to: "/app/attendance",
			label: "Attendance",
			icon: CalendarDays
		},
		{
			to: "/app/academics",
			label: "Assessments",
			icon: BookOpen
		},
		{
			to: "/app/results",
			label: "Marks",
			icon: ClipboardCheck
		},
		{
			to: "/app/behaviour",
			label: "Behaviour",
			icon: Shield
		},
		{
			to: "/app/students",
			label: "Students",
			icon: GraduationCap
		}
	],
	exam: [
		{
			to: "/app",
			label: "Exam office",
			icon: LayoutDashboard
		},
		{
			to: "/app/results",
			label: "Submissions",
			icon: ClipboardCheck
		},
		{
			to: "/app/academics",
			label: "Assessments",
			icon: BookOpen
		},
		{
			to: "/app/students",
			label: "Students",
			icon: GraduationCap
		}
	],
	bursar: [
		{
			to: "/app",
			label: "Finance",
			icon: LayoutDashboard
		},
		{
			to: "/app/finance",
			label: "Fees & payments",
			icon: Wallet
		},
		{
			to: "/app/students",
			label: "Students",
			icon: GraduationCap
		},
		{
			to: "/app/announcements",
			label: "Notices",
			icon: Megaphone
		}
	],
	parent: [],
	platform: [{
		to: "/app/platform",
		label: "Platform",
		icon: Building2
	}, {
		to: "/app",
		label: "Sunrise ops",
		icon: LayoutDashboard
	}]
};
function NavLinks({ items, onNavigate }) {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
		className: "flex flex-col gap-0.5",
		children: items.map((item) => {
			const active = item.to === "/app" ? pathname === "/app" : pathname === item.to || pathname.startsWith(item.to + "/");
			const Icon = item.icon;
			return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
				to: item.to,
				onClick: onNavigate,
				className: cn("flex h-10 items-center gap-2.5 rounded-md px-3 text-sm transition-colors", active ? "bg-secondary text-foreground" : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground"),
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4 shrink-0" }), item.label]
			}, item.to + item.label);
		})
	});
}
function PersonaSwitch() {
	const persona = useNexusSession((s) => s.persona);
	const setPersona = useNexusSession((s) => s.setPersona);
	const current = PERSONAS.find((p) => p.id === persona);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenu, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
			type: "button",
			className: "flex w-full items-center gap-2 rounded-lg bg-card px-2.5 py-2 text-left shadow-[var(--shadow-border)] transition-colors hover:bg-secondary",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
				name: current.label,
				tone: "teal",
				className: "size-8"
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
				className: "min-w-0 flex-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate text-xs font-medium text-foreground",
					children: current.label
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "block truncate text-[11px] text-muted-foreground",
					children: "View as"
				})]
			})]
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DropdownMenuContent, {
		align: "start",
		className: "w-72",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: "Enter a role" }),
			PERSONAS.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuItem, {
				onSelect: () => {
					setPersona(p.id);
					if (p.id === "parent") window.location.hash = "";
				},
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
					className: "flex flex-col",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: p.label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "text-[11px] text-muted-foreground",
						children: p.blurb
					})]
				})
			}, p.id)),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuSeparator, {}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DropdownMenuLabel, { children: "Roles are a tour of the same school, not separate logins." })
		]
	})] });
}
function Sidebar({ onNavigate }) {
	const items = NAV_BY_PERSONA[useNexusSession((s) => s.persona)];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex h-full flex-col",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "px-3 pb-5 pt-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
					to: "/",
					onClick: onNavigate,
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NexusWordmark, {})
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-3 px-1 text-[11px] uppercase tracking-[0.16em] text-muted-foreground",
					children: "Sunrise Academy"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "flex-1 overflow-y-auto px-2",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NavLinks, {
					items,
					onNavigate
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
				className: "space-y-3 p-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PersonaSwitch, {})
			})
		]
	});
}
function AppShell() {
	const [open, setOpen] = (0, import_react.useState)(false);
	const user = useCurrentUser();
	const persona = useNexusSession((s) => s.persona);
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	if (persona === "parent") return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ParentChrome, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background text-foreground",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
			className: "fixed inset-y-0 left-0 z-30 hidden w-60 border-r border-border bg-paper md:flex md:flex-col",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, {})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "md:pl-60",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "sticky top-0 z-20 flex h-14 items-center justify-between gap-3 border-b border-border bg-paper/90 px-4 backdrop-blur-sm",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center gap-2 md:hidden",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Sheet, {
							open,
							onOpenChange: setOpen,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTrigger, {
								asChild: true,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
									variant: "ghost",
									size: "icon",
									"aria-label": "Open menu",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Menu, { className: "size-5" })
								})
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SheetContent, {
								side: "left",
								className: "p-0",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetHeader, {
									className: "sr-only",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SheetTitle, { children: "Navigation" })
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Sidebar, { onNavigate: () => setOpen(false) })]
							})]
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(NexusWordmark, {})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "hidden truncate text-sm text-muted-foreground md:block",
						children: pathname === "/app" ? "Today · 15 September 2026 · Term 2" : "Sunrise Academy · Lilongwe"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "ml-auto flex items-center gap-3",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/app/announcements",
								className: "relative grid size-10 place-items-center rounded-full text-muted-foreground hover:bg-secondary",
								"aria-label": "Notifications",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Bell, { className: "size-4" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { className: "absolute right-2 top-2 size-1.5 rounded-full bg-primary" })]
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "hidden sm:block",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(UserButton, {})
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "sm:hidden",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, {
									name: user?.displayName ?? "You",
									tone: "ink"
								})
							})
						]
					})
				]
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "px-4 py-6 sm:px-6 lg:px-8",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			})]
		})]
	});
}
function ParentChrome() {
	const pathname = useRouterState({ select: (s) => s.location.pathname });
	const setPersona = useNexusSession((s) => s.setPersona);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-ink text-foam",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("header", {
				className: "sticky top-0 z-20 border-b border-foam/10 bg-ink/95 px-4 py-3 backdrop-blur",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "mx-auto flex max-w-lg items-center justify-between",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "font-display text-lg font-medium tracking-tight",
						children: "Sunrise Academy"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-[11px] uppercase tracking-[0.16em] text-mist",
						children: "Parent portal · Agnes Banda"
					})] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						onClick: () => setPersona("owner"),
						className: "text-xs text-mist underline-offset-4 hover:text-foam hover:underline",
						children: "School desk"
					})]
				})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("main", {
				className: "mx-auto max-w-lg px-4 pb-24 pt-6",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Outlet, {})
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
				className: "fixed inset-x-0 bottom-0 z-20 border-t border-foam/10 bg-ink/95 pb-[env(safe-area-inset-bottom)]",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "mx-auto grid max-w-lg grid-cols-5",
					children: [
						{
							to: "/app",
							label: "Home",
							icon: LayoutDashboard
						},
						{
							to: "/app/results",
							label: "Results",
							icon: ClipboardCheck
						},
						{
							to: "/app/attendance",
							label: "Attend.",
							icon: CalendarDays
						},
						{
							to: "/app/finance",
							label: "Fees",
							icon: Wallet
						},
						{
							to: "/app/announcements",
							label: "Notices",
							icon: Megaphone
						}
					].map((t) => {
						const Icon = t.icon;
						const active = t.to === "/app" ? pathname === "/app" : pathname.startsWith(t.to);
						return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
							to: t.to,
							className: cn("flex h-14 flex-col items-center justify-center gap-0.5 text-[10px] uppercase tracking-wide", active ? "text-foam" : "text-mist"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Icon, { className: "size-4" }), t.label]
						}, t.to);
					})
				})
			})
		]
	});
}
function AppLayout() {
	const { user, isPending } = useCurrentUserState();
	if (isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-background p-6",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-10 w-48" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-8 grid gap-3 md:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-28" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-28" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-28" }),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-28" })
			]
		})]
	});
	if (!user) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RedirectToSignIn, {});
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(AppShell, {});
}
//#endregion
export { AppLayout as component };
