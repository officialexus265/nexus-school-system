import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { t as Button } from "./button-Bwm68GMl.mjs";
import { y as ArrowRight } from "../_libs/lucide-react.mjs";
import { i as useCurrentUserState, t as NexusMark } from "./use-current-user-DFJztN0m.mjs";
import { n as SignedIn, r as SignedOut } from "./gates-B2xIAI7e.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-C33fIDip.js
var import_jsx_runtime = require_jsx_runtime();
function Home() {
	const { isPending } = useCurrentUserState();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "min-h-dvh bg-ink text-foam",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "ledger-grid pointer-events-none fixed inset-0 opacity-30" }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
				className: "relative z-10 mx-auto flex max-w-6xl items-center justify-between px-5 py-5",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
					to: "/",
					className: "flex items-center gap-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(NexusMark, { className: "text-foam" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
						className: "font-display text-xl font-medium tracking-tight",
						children: "NEXUS"
					})]
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("nav", {
					className: "flex items-center gap-3",
					children: isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-10 w-28 animate-pulse rounded-md bg-ink-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								variant: "ghost",
								className: "text-foam hover:bg-ink-3 hover:text-foam",
								children: "Sign in"
							})
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/app",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
								className: "bg-foam text-ink hover:bg-foam/90",
								children: "Open workspace"
							})
						}) }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
							to: "/login",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
								className: "bg-foam text-ink hover:bg-foam/90",
								children: ["Enter", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
							})
						}) })
					] })
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
				className: "relative z-10",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mx-auto grid max-w-6xl gap-12 px-5 pb-20 pt-10 md:grid-cols-[1.1fr_0.9fr] md:items-end md:pt-20",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-medium uppercase tracking-[0.22em] text-mist",
								children: "Multi-school operating platform"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
								className: "mt-4 max-w-xl font-display text-5xl font-medium leading-[1.05] tracking-tight text-foam sm:text-6xl md:text-7xl",
								children: "The operating system for schools."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-6 max-w-md text-base leading-relaxed text-mist",
								children: "One platform. Isolated tenants. Marks stay draft until an authorised person publishes them. Parents see only what the school releases."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-8 flex flex-wrap gap-3",
								children: isPending ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "h-11 w-40 animate-pulse rounded-md bg-ink-3" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedIn, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/app",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "lg",
										className: "bg-foam text-ink hover:bg-foam/90",
										children: ["Continue to desk", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
									})
								}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SignedOut, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
									to: "/login",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Button, {
										size: "lg",
										className: "bg-foam text-ink hover:bg-foam/90",
										children: ["Open a workspace", /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ArrowRight, { className: "size-4" })]
									})
								}) })] })
							})
						] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(HeroCard, {})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("section", {
						className: "border-t border-foam/10",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-auto grid max-w-6xl gap-px bg-foam/10 md:grid-cols-3",
							children: [
								{
									k: "01",
									t: "Tenant isolation",
									d: "Every school is a sealed ledger. Staff, students, fees and marks never leak across campuses."
								},
								{
									k: "02",
									t: "Permissioned work",
									d: "Roles are collections of permissions. A bursar cannot publish results. A teacher cannot reverse a receipt."
								},
								{
									k: "03",
									t: "Published, not leaked",
									d: "Draft → submit → review → approve → confirm. Parents are notified only after the last signature."
								}
							].map((item) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "bg-ink px-6 py-10",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "font-mono text-xs text-mist",
										children: item.k
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
										className: "mt-3 font-display text-2xl font-medium tracking-tight",
										children: item.t
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-2 max-w-sm text-sm leading-relaxed text-mist",
										children: item.d
									})
								]
							}, item.k))
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
						className: "mx-auto max-w-6xl px-5 py-20",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-[11px] font-medium uppercase tracking-[0.22em] text-mist",
								children: "Modules"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "mt-3 font-display text-4xl font-medium tracking-tight",
								children: "A full school desk."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "mt-10 grid gap-3 sm:grid-cols-2 lg:grid-cols-4",
								children: [
									["People", "Students, parents, teachers, verified child links."],
									["Academics", "Years, terms, classes, streams, subjects, assignments."],
									["Results", "Configurable grading, ranking, locked report cards."],
									["Attendance", "Daily register with absence alerts to parents."],
									["Finance", "Charges, allocations, receipts — never silent deletes."],
									["Behaviour", "Incidents, cases, meetings, parent visibility rules."],
									["Parent portal", "School colours, only published records."],
									["Audit", "Money, marks, permissions and publishing events."]
								].map(([t, d]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "rounded-xl border border-foam/10 bg-ink-2 p-5",
									children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
										className: "font-display text-lg font-medium",
										children: t
									}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
										className: "mt-1 text-sm text-mist",
										children: d
									})]
								}, t))
							})
						]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("footer", {
						className: "border-t border-foam/10 px-5 py-8",
						children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mx-auto flex max-w-6xl flex-col gap-2 sm:flex-row sm:items-center sm:justify-between",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "font-display text-sm",
								children: "NEXUS"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "text-xs text-mist",
								children: "A configurable school operating platform."
							})]
						})
					})
				]
			})
		]
	});
}
function HeroCard() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-2xl bg-paper p-5 text-ink shadow-[var(--shadow-lift)] sm:p-6",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
				children: "Publish results"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h3", {
				className: "mt-2 font-display text-2xl font-medium tracking-tight",
				children: "Form 2A · Term 2"
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dl", {
				className: "mt-5 space-y-2 text-sm",
				children: [
					["Academic year", "2026"],
					["Students", "4"],
					["Mathematics", "Submitted"],
					["English", "Verified"],
					["Science", "Draft — blocked"]
				].map(([k, v]) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex items-center justify-between border-b border-line py-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("dt", {
						className: "text-muted-foreground",
						children: k
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("dd", {
						className: "tabular-nums",
						children: v
					})]
				}, k))
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-4 text-xs leading-relaxed text-muted-foreground",
				children: "Published results become visible to authorised parents. This action is written to the audit log and cannot be undone without a reversal."
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "mt-5 flex gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex h-10 flex-1 items-center justify-center rounded-md border border-border text-sm",
					children: "Cancel"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
					className: "flex h-10 flex-1 items-center justify-center rounded-md bg-ink text-sm text-foam",
					children: "Confirm & publish"
				})]
			})
		]
	});
}
//#endregion
export { Home as component };
