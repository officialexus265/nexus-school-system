import { l as num } from "./utils-CZhKFE8j.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/selectors-ZxoSqobI.js
function classLabel(c) {
	if (!c) return "Unplaced";
	return c.stream ? `${c.name} ${c.stream}` : c.name;
}
function classById(snap, id) {
	return snap.classes.find((c) => c.id === id);
}
function currentTerm(snap) {
	return snap.terms.find((t) => t.is_current) ?? snap.terms[snap.terms.length - 1];
}
function publishedTerm(snap) {
	return snap.terms.find((t) => !t.is_current) ?? snap.terms[0];
}
function attendanceRate(rows) {
	if (rows.length === 0) return 0;
	const ok = rows.filter((r) => r.status === "PRESENT" || r.status === "LATE" || r.status === "EXCUSED").length;
	return Math.round(ok / rows.length * 100);
}
function studentAttendance(snap, studentId) {
	return attendanceRate(snap.attendance.filter((a) => a.student_id === studentId));
}
function studentAverage(snap, studentId, termId, onlyPublished = false) {
	const rows = snap.results.filter((r) => r.student_id === studentId && r.term_id === termId && (!onlyPublished || r.status === "PUBLISHED" || r.status === "LOCKED"));
	if (rows.length === 0) return null;
	return Math.round(rows.reduce((a, r) => a + num(r.overall_score), 0) / rows.length * 10) / 10;
}
function studentPosition(snap, studentId, termId) {
	return snap.results.find((r) => r.student_id === studentId && r.term_id === termId && r.position)?.position ?? null;
}
function chargeBalance(c) {
	return Math.max(0, num(c.amount) - num(c.paid));
}
function studentBalance(snap, studentId) {
	return snap.charges.filter((c) => c.student_id === studentId).reduce((a, c) => a + chargeBalance(c), 0);
}
function schoolOutstanding(snap) {
	return snap.charges.reduce((a, c) => a + chargeBalance(c), 0);
}
function schoolCollected(snap) {
	return snap.charges.reduce((a, c) => a + num(c.paid), 0);
}
function parentChildren(snap, parentId) {
	const ids = new Set(snap.parentLinks.filter((l) => l.parent_id === parentId).map((l) => l.student_id));
	return snap.students.filter((s) => ids.has(s.id));
}
function defaultParent(snap) {
	return snap.parents.find((p) => p.full_name.includes("Agnes")) ?? snap.parents[0];
}
function defaultTeacher(snap) {
	return snap.staff.find((s) => s.full_name.includes("James Banda")) ?? snap.staff.find((s) => s.role === "teacher");
}
function todayIso() {
	return "2026-09-15";
}
//#endregion
export { currentTerm as a, parentChildren as c, schoolOutstanding as d, studentAttendance as f, todayIso as g, studentPosition as h, classLabel as i, publishedTerm as l, studentBalance as m, chargeBalance as n, defaultParent as o, studentAverage as p, classById as r, defaultTeacher as s, attendanceRate as t, schoolCollected as u };
