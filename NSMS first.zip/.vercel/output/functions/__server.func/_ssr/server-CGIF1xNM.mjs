import { a as getSql, l as num, o as gradeFromScore } from "./utils-CZhKFE8j.mjs";
import { i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DObhFC7t.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/server-CGIF1xNM.js
var createServerRpc = (serverFnMeta, splitImportFn) => {
	const url = "/_serverFn/" + serverFnMeta.id;
	return Object.assign(splitImportFn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
function nid(userId, key) {
	return `${userId}:${key}`;
}
async function ins(sql, table, row) {
	const keys = Object.keys(row);
	const vals = Object.values(row);
	const ph = keys.map((_, i) => `$${i + 1}`).join(", ");
	await sql.query(`insert into ${table} (${keys.join(", ")}) values (${ph})`, vals);
}
async function insMany(sql, table, rows) {
	for (const row of rows) await ins(sql, table, row);
}
async function seedWorkspace(sql, userId) {
	const id = (key) => nid(userId, key);
	const u = userId;
	const sunrise = id("sch-sunrise");
	const lakeview = id("sch-lakeview");
	const karonga = id("sch-karonga");
	await insMany(sql, "schools", [
		{
			id: sunrise,
			user_id: u,
			slug: "sunrise",
			name: "Sunrise Academy",
			registration_number: "EDU-LLW-2014-088",
			address: "Area 10, Kenyatta Drive",
			district: "Lilongwe",
			city: "Lilongwe",
			country: "Malawi",
			phone: "+265 1 755 210",
			email: "office@sunrise.ac.mw",
			website: "sunrise.ac.mw",
			motto: "Light. Discipline. Excellence.",
			school_type: "Primary & Secondary",
			boarding_status: "Day and boarding",
			status: "ACTIVE",
			logo_mark: "S",
			primary_color: "#2F5F5A",
			secondary_color: "#F3F0E8",
			timezone: "Africa/Blantyre",
			currency: "MWK",
			subscription_plan: "Campus",
			activation_fee: 85e4,
			student_capacity: 640
		},
		{
			id: lakeview,
			user_id: u,
			slug: "lakeview",
			name: "Lakeview Secondary",
			registration_number: "EDU-BT-2019-041",
			address: "Mandala Road",
			district: "Blantyre",
			city: "Blantyre",
			country: "Malawi",
			phone: "+265 1 822 440",
			email: "admin@lakeview.ac.mw",
			website: null,
			motto: "By the lake, toward the horizon.",
			school_type: "Secondary",
			boarding_status: "Day",
			status: "PENDING_PAYMENT",
			logo_mark: "L",
			primary_color: "#1E3D3A",
			secondary_color: "#F3F0E8",
			timezone: "Africa/Blantyre",
			currency: "MWK",
			subscription_plan: "Campus",
			activation_fee: 85e4,
			student_capacity: 420
		},
		{
			id: karonga,
			user_id: u,
			slug: "karonga",
			name: "Karonga Girls High",
			registration_number: "EDU-KA-2011-016",
			address: "M1 North",
			district: "Karonga",
			city: "Karonga",
			country: "Malawi",
			phone: "+265 1 362 110",
			email: "head@karongagirls.ac.mw",
			website: null,
			motto: "Character before applause.",
			school_type: "Secondary",
			boarding_status: "Boarding",
			status: "GRACE_PERIOD",
			logo_mark: "K",
			primary_color: "#2F5F5A",
			secondary_color: "#F3F0E8",
			timezone: "Africa/Blantyre",
			currency: "MWK",
			subscription_plan: "Studio",
			activation_fee: 62e4,
			student_capacity: 280
		}
	]);
	await insMany(sql, "staff", [
		[
			"st-owner",
			"Dr. Chimwemwe Phiri",
			"owner",
			"School Owner",
			"CP"
		],
		[
			"st-head",
			"Mrs. Grace Mvula",
			"head",
			"Head Teacher",
			"GM"
		],
		[
			"st-deputy",
			"Mr. Blessings Chirwa",
			"deputy",
			"Deputy Head",
			"BC"
		],
		[
			"st-bursar",
			"Mrs. Thandiwe Banda",
			"bursar",
			"Bursar",
			"TB"
		],
		[
			"st-exam",
			"Mr. Patrick Gondwe",
			"exam",
			"Examination Officer",
			"PG"
		],
		[
			"st-james",
			"Mr. James Banda",
			"teacher",
			"Mathematics",
			"JB"
		],
		[
			"st-linda",
			"Ms. Linda Phiri",
			"teacher",
			"English",
			"LP"
		],
		[
			"st-yusuf",
			"Mr. Yusuf Mwale",
			"teacher",
			"Science",
			"YM"
		],
		[
			"st-mercy",
			"Mrs. Mercy Kachale",
			"teacher",
			"Standard 5 class teacher",
			"MK"
		],
		[
			"st-isaac",
			"Mr. Isaac Nkhoma",
			"teacher",
			"Standard 7 class teacher",
			"IN"
		]
	].map(([key, name, role, title, initials]) => ({
		id: id(key),
		user_id: u,
		school_id: sunrise,
		full_name: name,
		email: `${key.replace("st-", "")}@sunrise.ac.mw`,
		phone: "+265 99 100 00" + key.length,
		role,
		title,
		status: "ACTIVE",
		initials
	})));
	await insMany(sql, "classes", [
		[
			"cl-f2a",
			"Secondary",
			"Form 2",
			"A",
			12
		],
		[
			"cl-f1a",
			"Secondary",
			"Form 1",
			"A",
			11
		],
		[
			"cl-f1b",
			"Secondary",
			"Form 1",
			"B",
			11
		],
		[
			"cl-s7",
			"Primary",
			"Standard 7",
			null,
			7
		],
		[
			"cl-s5",
			"Primary",
			"Standard 5",
			null,
			5
		]
	].map(([key, section, name, stream, order]) => ({
		id: id(key),
		user_id: u,
		school_id: sunrise,
		section,
		name,
		stream,
		level_order: order
	})));
	await insMany(sql, "subjects", [
		[
			"sub-math",
			"Mathematics",
			"MATH",
			"Secondary"
		],
		[
			"sub-eng",
			"English",
			"ENG",
			"Secondary"
		],
		[
			"sub-sci",
			"Science",
			"SCI",
			"Secondary"
		],
		[
			"sub-pmath",
			"Mathematics",
			"PMATH",
			"Primary"
		],
		[
			"sub-peng",
			"English",
			"PENG",
			"Primary"
		],
		[
			"sub-pchichewa",
			"Chichewa",
			"CHI",
			"Primary"
		]
	].map(([key, name, code, section]) => ({
		id: id(key),
		user_id: u,
		school_id: sunrise,
		name,
		code,
		section
	})));
	await insMany(sql, "teacher_assignments", [
		[
			"st-james",
			"cl-f2a",
			"sub-math",
			true
		],
		[
			"st-james",
			"cl-f1a",
			"sub-math",
			false
		],
		[
			"st-james",
			"cl-f1b",
			"sub-math",
			false
		],
		[
			"st-linda",
			"cl-f2a",
			"sub-eng",
			false
		],
		[
			"st-linda",
			"cl-f1a",
			"sub-eng",
			true
		],
		[
			"st-yusuf",
			"cl-f2a",
			"sub-sci",
			false
		],
		[
			"st-yusuf",
			"cl-f1a",
			"sub-sci",
			false
		],
		[
			"st-mercy",
			"cl-s5",
			"sub-pmath",
			true
		],
		[
			"st-mercy",
			"cl-s5",
			"sub-peng",
			false
		],
		[
			"st-isaac",
			"cl-s7",
			"sub-pmath",
			true
		],
		[
			"st-isaac",
			"cl-s7",
			"sub-peng",
			false
		]
	].map(([staff, cls, sub, isCt], i) => ({
		id: id(`ta-${i}`),
		user_id: u,
		school_id: sunrise,
		staff_id: id(staff),
		class_id: id(cls),
		subject_id: id(sub),
		is_class_teacher: isCt
	})));
	await insMany(sql, "students", [
		[
			"stu-john",
			"SA-2024-014",
			"John",
			"Banda",
			"M",
			"2009-03-12",
			"cl-f2a",
			"Area 10"
		],
		[
			"stu-chisomo",
			"SA-2024-015",
			"Chisomo",
			"Mvula",
			"F",
			"2009-07-02",
			"cl-f2a",
			"Area 18"
		],
		[
			"stu-tiya",
			"SA-2024-016",
			"Tiyamike",
			"Gondwe",
			"M",
			"2009-11-19",
			"cl-f2a",
			"Kanengo"
		],
		[
			"stu-faith",
			"SA-2024-017",
			"Faith",
			"Chirwa",
			"F",
			"2009-01-28",
			"cl-f2a",
			"Area 47"
		],
		[
			"stu-blessings",
			"SA-2025-021",
			"Blessings",
			"Phiri",
			"M",
			"2010-04-08",
			"cl-f1a",
			"Area 12"
		],
		[
			"stu-tamara",
			"SA-2025-022",
			"Tamara",
			"Mwale",
			"F",
			"2010-09-14",
			"cl-f1a",
			"Area 9"
		],
		[
			"stu-patrick",
			"SA-2025-031",
			"Patrick",
			"Nkhoma",
			"M",
			"2010-06-21",
			"cl-f1b",
			"Area 25"
		],
		[
			"stu-linda",
			"SA-2025-032",
			"Linda",
			"Kachale",
			"F",
			"2010-12-03",
			"cl-f1b",
			"Area 15"
		],
		[
			"stu-mary",
			"SA-2023-008",
			"Mary",
			"Banda",
			"F",
			"2014-05-16",
			"cl-s5",
			"Area 10"
		],
		[
			"stu-yankho",
			"SA-2023-009",
			"Yankho",
			"Banda",
			"M",
			"2014-08-11",
			"cl-s5",
			"Area 18"
		],
		[
			"stu-mercy",
			"SA-2022-004",
			"Mercy",
			"Mvula",
			"F",
			"2012-02-27",
			"cl-s7",
			"Area 18"
		],
		[
			"stu-gift",
			"SA-2022-005",
			"Gift",
			"Phiri",
			"M",
			"2012-10-09",
			"cl-s7",
			"Area 12"
		]
	].map(([key, adm, first, last, gender, dob, cls, address]) => ({
		id: id(key),
		user_id: u,
		school_id: sunrise,
		admission_number: adm,
		first_name: first,
		last_name: last,
		gender,
		date_of_birth: dob,
		class_id: id(cls),
		status: "ACTIVE",
		admission_date: "2024-01-15",
		address
	})));
	await insMany(sql, "parents", [
		[
			"par-agnes",
			"Agnes Banda",
			"+265 99 811 2201"
		],
		[
			"par-ellen",
			"Ellen Mvula",
			"+265 88 422 1094"
		],
		[
			"par-joseph",
			"Joseph Gondwe",
			"+265 99 300 4412"
		],
		[
			"par-ruth",
			"Ruth Chirwa",
			"+265 88 771 0098"
		],
		[
			"par-peter",
			"Peter Phiri",
			"+265 99 214 8830"
		],
		[
			"par-alice",
			"Alice Mwale",
			"+265 88 650 2177"
		]
	].map(([key, name, phone]) => ({
		id: id(key),
		user_id: u,
		school_id: sunrise,
		full_name: name,
		phone,
		email: `${key.replace("par-", "")}@mail.mw`,
		verification_status: "VERIFIED"
	})));
	await insMany(sql, "parent_students", [
		[
			"par-agnes",
			"stu-john",
			"Mother"
		],
		[
			"par-agnes",
			"stu-mary",
			"Mother"
		],
		[
			"par-ellen",
			"stu-chisomo",
			"Mother"
		],
		[
			"par-ellen",
			"stu-mercy",
			"Mother"
		],
		[
			"par-joseph",
			"stu-tiya",
			"Father"
		],
		[
			"par-ruth",
			"stu-faith",
			"Mother"
		],
		[
			"par-peter",
			"stu-blessings",
			"Father"
		],
		[
			"par-peter",
			"stu-gift",
			"Father"
		],
		[
			"par-alice",
			"stu-tamara",
			"Mother"
		],
		[
			"par-alice",
			"stu-yankho",
			"Aunt"
		]
	].map(([p, s, rel], i) => ({
		id: id(`ps-${i}`),
		user_id: u,
		parent_id: id(p),
		student_id: id(s),
		relationship: rel,
		is_primary: true
	})));
	const year = id("yr-2026");
	await ins(sql, "academic_years", {
		id: year,
		user_id: u,
		school_id: sunrise,
		name: "2026",
		is_current: true
	});
	const t1 = id("term-1");
	const t2 = id("term-2");
	await insMany(sql, "terms", [{
		id: t1,
		user_id: u,
		school_id: sunrise,
		academic_year_id: year,
		name: "Term 1",
		term_number: 1,
		is_current: false,
		start_date: "2026-01-13",
		end_date: "2026-04-10"
	}, {
		id: t2,
		user_id: u,
		school_id: sunrise,
		academic_year_id: year,
		name: "Term 2",
		term_number: 2,
		is_current: true,
		start_date: "2026-05-04",
		end_date: "2026-08-14"
	}]);
	await insMany(sql, "assessments", [
		{
			id: id("as-math-quiz"),
			user_id: u,
			school_id: sunrise,
			class_id: id("cl-f2a"),
			subject_id: id("sub-math"),
			staff_id: id("st-james"),
			term_id: t2,
			name: "Algebra quiz",
			assessment_type: "Quiz",
			maximum_marks: 20,
			weight: 10,
			due_date: "2026-06-12",
			status: "MARKED"
		},
		{
			id: id("as-eng-essay"),
			user_id: u,
			school_id: sunrise,
			class_id: id("cl-f2a"),
			subject_id: id("sub-eng"),
			staff_id: id("st-linda"),
			term_id: t2,
			name: "Narrative essay",
			assessment_type: "Assignment",
			maximum_marks: 30,
			weight: 10,
			due_date: "2026-06-20",
			status: "MARKED"
		},
		{
			id: id("as-sci-prac"),
			user_id: u,
			school_id: sunrise,
			class_id: id("cl-f2a"),
			subject_id: id("sub-sci"),
			staff_id: id("st-yusuf"),
			term_id: t2,
			name: "Lab practical",
			assessment_type: "Practical",
			maximum_marks: 25,
			weight: 10,
			due_date: "2026-07-02",
			status: "OPEN"
		}
	]);
	const f2a = [
		"stu-john",
		"stu-chisomo",
		"stu-tiya",
		"stu-faith"
	];
	const quizScores = {
		"stu-john": 16,
		"stu-chisomo": 18,
		"stu-tiya": 12,
		"stu-faith": 15
	};
	const essayScores = {
		"stu-john": 24,
		"stu-chisomo": 27,
		"stu-tiya": 19,
		"stu-faith": 22
	};
	await insMany(sql, "assessment_scores", f2a.map((s) => ({
		id: id(`sc-q-${s}`),
		user_id: u,
		assessment_id: id("as-math-quiz"),
		student_id: id(s),
		score: quizScores[s],
		comment: null
	})));
	await insMany(sql, "assessment_scores", f2a.map((s) => ({
		id: id(`sc-e-${s}`),
		user_id: u,
		assessment_id: id("as-eng-essay"),
		student_id: id(s),
		score: essayScores[s],
		comment: null
	})));
	const t1Marks = {
		"stu-john": {
			"sub-math": {
				c: 78,
				e: 84,
				comment: "Consistent and careful."
			},
			"sub-eng": {
				c: 74,
				e: 77,
				comment: "Voice is forming. Keep reading."
			},
			"sub-sci": {
				c: 88,
				e: 93,
				comment: "Excellent practical work."
			}
		},
		"stu-chisomo": {
			"sub-math": {
				c: 90,
				e: 92,
				comment: "Top of the class."
			},
			"sub-eng": {
				c: 86,
				e: 89,
				comment: "Fluent and precise."
			},
			"sub-sci": {
				c: 84,
				e: 86,
				comment: "Strong conceptual grasp."
			}
		},
		"stu-tiya": {
			"sub-math": {
				c: 62,
				e: 68,
				comment: "Needs more practice on algebra."
			},
			"sub-eng": {
				c: 70,
				e: 72,
				comment: "Improving structure."
			},
			"sub-sci": {
				c: 76,
				e: 80,
				comment: "Good lab technique."
			}
		},
		"stu-faith": {
			"sub-math": {
				c: 80,
				e: 76,
				comment: "Solid. Watch careless errors."
			},
			"sub-eng": {
				c: 82,
				e: 85,
				comment: "Beautiful essays."
			},
			"sub-sci": {
				c: 71,
				e: 74,
				comment: "Revise formulae."
			}
		}
	};
	const t1Results = [];
	const t1Subs = [];
	for (const sub of [
		"sub-math",
		"sub-eng",
		"sub-sci"
	]) {
		t1Subs.push({
			id: id(`rs-t1-${sub}`),
			user_id: u,
			school_id: sunrise,
			class_id: id("cl-f2a"),
			subject_id: id(sub),
			term_id: t1,
			staff_id: id(sub === "sub-math" ? "st-james" : sub === "sub-eng" ? "st-linda" : "st-yusuf"),
			status: "PUBLISHED",
			submitted_at: "2026-04-02T10:00:00Z",
			reviewed_at: "2026-04-04T09:00:00Z",
			approved_at: "2026-04-05T11:00:00Z",
			published_at: "2026-04-06T08:00:00Z",
			published_by: "Mrs. Grace Mvula"
		});
		for (const s of f2a) {
			const m = t1Marks[s][sub];
			const overall = Math.round(m.c * .4 + m.e * .6);
			t1Results.push({
				id: id(`res-t1-${s}-${sub}`),
				user_id: u,
				school_id: sunrise,
				student_id: id(s),
				term_id: t1,
				subject_id: id(sub),
				continuous_score: m.c,
				exam_score: m.e,
				overall_score: overall,
				grade: gradeFromScore(overall),
				position: null,
				status: "PUBLISHED",
				teacher_comment: m.comment
			});
		}
	}
	await insMany(sql, "result_submissions", t1Subs);
	await insMany(sql, "student_results", t1Results);
	const t1Overall = f2a.map((s) => {
		return {
			s,
			avg: [
				"sub-math",
				"sub-eng",
				"sub-sci"
			].reduce((a, sub) => {
				const m = t1Marks[s][sub];
				return a + Math.round(m.c * .4 + m.e * .6);
			}, 0) / 3
		};
	});
	t1Overall.sort((a, b) => b.avg - a.avg);
	for (let i = 0; i < t1Overall.length; i++) {
		const s = t1Overall[i].s;
		await sql.query(`update student_results set position = $1 where user_id = $2 and student_id = $3 and term_id = $4`, [
			i + 1,
			u,
			id(s),
			t1
		]);
	}
	const t2Marks = {
		"stu-john": {
			"sub-math": {
				c: 80,
				e: 81,
				comment: "Steady improvement."
			},
			"sub-eng": {
				c: 76,
				e: 79,
				comment: "Clearer argument this term."
			},
			"sub-sci": {
				c: 90,
				e: 88,
				comment: "Draft — awaiting practical."
			}
		},
		"stu-chisomo": {
			"sub-math": {
				c: 92,
				e: 94,
				comment: "Outstanding."
			},
			"sub-eng": {
				c: 88,
				e: 90,
				comment: "Publishable writing."
			},
			"sub-sci": {
				c: 85,
				e: 87,
				comment: "Draft."
			}
		},
		"stu-tiya": {
			"sub-math": {
				c: 64,
				e: 70,
				comment: "Better on word problems."
			},
			"sub-eng": {
				c: 71,
				e: 73,
				comment: "Keep the reading log."
			},
			"sub-sci": {
				c: 74,
				e: 76,
				comment: "Draft."
			}
		},
		"stu-faith": {
			"sub-math": {
				c: 78,
				e: 80,
				comment: "Cleaner algebra."
			},
			"sub-eng": {
				c: 84,
				e: 86,
				comment: "Strong voice."
			},
			"sub-sci": {
				c: 72,
				e: 75,
				comment: "Draft."
			}
		}
	};
	const t2Status = {
		"sub-math": "SUBMITTED",
		"sub-eng": "VERIFIED",
		"sub-sci": "DRAFT"
	};
	for (const sub of [
		"sub-math",
		"sub-eng",
		"sub-sci"
	]) {
		const st = t2Status[sub];
		await ins(sql, "result_submissions", {
			id: id(`rs-t2-${sub}`),
			user_id: u,
			school_id: sunrise,
			class_id: id("cl-f2a"),
			subject_id: id(sub),
			term_id: t2,
			staff_id: id(sub === "sub-math" ? "st-james" : sub === "sub-eng" ? "st-linda" : "st-yusuf"),
			status: st,
			submitted_at: st === "DRAFT" ? null : "2026-08-01T10:00:00Z",
			reviewed_at: st === "VERIFIED" ? "2026-08-03T09:00:00Z" : null,
			approved_at: null,
			published_at: null,
			published_by: null
		});
		for (const s of f2a) {
			const m = t2Marks[s][sub];
			const overall = Math.round(m.c * .4 + m.e * .6);
			await ins(sql, "student_results", {
				id: id(`res-t2-${s}-${sub}`),
				user_id: u,
				school_id: sunrise,
				student_id: id(s),
				term_id: t2,
				subject_id: id(sub),
				continuous_score: m.c,
				exam_score: m.e,
				overall_score: overall,
				grade: gradeFromScore(overall),
				position: null,
				status: st,
				teacher_comment: m.comment
			});
		}
	}
	const days = [
		"2026-09-04",
		"2026-09-07",
		"2026-09-08",
		"2026-09-09",
		"2026-09-10",
		"2026-09-11",
		"2026-09-14",
		"2026-09-15"
	];
	const attPattern = {
		"stu-john": [
			"P",
			"P",
			"P",
			"L",
			"P",
			"P",
			"P",
			"P"
		],
		"stu-chisomo": [
			"P",
			"P",
			"P",
			"P",
			"P",
			"P",
			"P",
			"P"
		],
		"stu-tiya": [
			"P",
			"A",
			"P",
			"P",
			"P",
			"L",
			"P",
			"P"
		],
		"stu-faith": [
			"P",
			"P",
			"P",
			"P",
			"E",
			"P",
			"P",
			"P"
		],
		"stu-mary": [
			"P",
			"P",
			"P",
			"P",
			"P",
			"P",
			"P",
			"P"
		]
	};
	const map = {
		P: "PRESENT",
		A: "ABSENT",
		L: "LATE",
		E: "EXCUSED"
	};
	const attRows = [];
	for (const [stu, pattern] of Object.entries(attPattern)) pattern.forEach((code, i) => {
		attRows.push({
			id: id(`att-${stu}-${days[i]}`),
			user_id: u,
			school_id: sunrise,
			student_id: id(stu),
			class_id: id(stu === "stu-mary" ? "cl-s5" : "cl-f2a"),
			date: days[i],
			status: map[code],
			recorded_by: "Mr. James Banda"
		});
	});
	await insMany(sql, "attendance", attRows);
	await insMany(sql, "behaviour_records", [
		{
			id: id("beh-1"),
			user_id: u,
			school_id: sunrise,
			student_id: id("stu-john"),
			category: "Helpfulness",
			kind: "POSITIVE",
			severity: "Low",
			points: 5,
			description: "Tutored a Form 1 student after games.",
			date: "2026-09-08",
			status: "CLOSED",
			recorded_by: "Mr. James Banda"
		},
		{
			id: id("beh-2"),
			user_id: u,
			school_id: sunrise,
			student_id: id("stu-tiya"),
			category: "Punctuality",
			kind: "NEGATIVE",
			severity: "Low",
			points: -2,
			description: "Late to first period without a note.",
			date: "2026-09-11",
			status: "OPEN",
			recorded_by: "Mrs. Grace Mvula"
		},
		{
			id: id("beh-3"),
			user_id: u,
			school_id: sunrise,
			student_id: id("stu-chisomo"),
			category: "Leadership",
			kind: "POSITIVE",
			severity: "Medium",
			points: 8,
			description: "Led the science club demonstration for Standard 7.",
			date: "2026-09-04",
			status: "CLOSED",
			recorded_by: "Mr. Yusuf Mwale"
		}
	]);
	const feeDefs = [
		[
			"fee-tu-f2",
			"Tuition",
			45e4,
			"cl-f2a"
		],
		[
			"fee-ex-f2",
			"Examination fee",
			25e3,
			"cl-f2a"
		],
		[
			"fee-tr-f2",
			"Transport",
			8e4,
			"cl-f2a"
		],
		[
			"fee-tu-s5",
			"Tuition",
			28e4,
			"cl-s5"
		],
		[
			"fee-un-s5",
			"Uniform",
			45e3,
			"cl-s5"
		]
	];
	await insMany(sql, "fee_structures", feeDefs.map(([key, name, amount, cls]) => ({
		id: id(key),
		user_id: u,
		school_id: sunrise,
		name,
		class_id: cls ? id(cls) : null,
		term_id: t2,
		amount,
		due_date: "2026-09-30",
		mandatory: true
	})));
	await insMany(sql, "student_charges", [
		[
			"ch-john-tu",
			"stu-john",
			"fee-tu-f2",
			45e4,
			3e5,
			"PARTIAL"
		],
		[
			"ch-john-ex",
			"stu-john",
			"fee-ex-f2",
			25e3,
			0,
			"UNPAID"
		],
		[
			"ch-john-tr",
			"stu-john",
			"fee-tr-f2",
			8e4,
			8e4,
			"PAID"
		],
		[
			"ch-chi-tu",
			"stu-chisomo",
			"fee-tu-f2",
			45e4,
			45e4,
			"PAID"
		],
		[
			"ch-chi-ex",
			"stu-chisomo",
			"fee-ex-f2",
			25e3,
			25e3,
			"PAID"
		],
		[
			"ch-tiya-tu",
			"stu-tiya",
			"fee-tu-f2",
			45e4,
			15e4,
			"PARTIAL"
		],
		[
			"ch-mary-tu",
			"stu-mary",
			"fee-tu-s5",
			28e4,
			28e4,
			"PAID"
		],
		[
			"ch-mary-un",
			"stu-mary",
			"fee-un-s5",
			45e3,
			0,
			"UNPAID"
		]
	].map(([key, stu, fee, amount, paid, status]) => ({
		id: id(key),
		user_id: u,
		school_id: sunrise,
		student_id: id(stu),
		fee_structure_id: id(fee),
		description: feeDefs.find((f) => f[0] === fee)?.[1] ?? "Fee",
		amount,
		paid,
		due_date: "2026-09-30",
		status
	})));
	await insMany(sql, "payments", [
		{
			id: id("pay-1"),
			user_id: u,
			school_id: sunrise,
			student_id: id("stu-john"),
			parent_id: id("par-agnes"),
			amount: 3e5,
			method: "Airtel Money",
			reference: "AM-229184",
			payment_date: "2026-08-20",
			status: "VERIFIED",
			recorded_by: "Mrs. Thandiwe Banda",
			receipt_number: "SA-2026-0412"
		},
		{
			id: id("pay-2"),
			user_id: u,
			school_id: sunrise,
			student_id: id("stu-john"),
			parent_id: id("par-agnes"),
			amount: 8e4,
			method: "Cash",
			reference: null,
			payment_date: "2026-08-22",
			status: "VERIFIED",
			recorded_by: "Mrs. Thandiwe Banda",
			receipt_number: "SA-2026-0418"
		},
		{
			id: id("pay-3"),
			user_id: u,
			school_id: sunrise,
			student_id: id("stu-chisomo"),
			parent_id: id("par-ellen"),
			amount: 475e3,
			method: "Bank transfer",
			reference: "NBM-881203",
			payment_date: "2026-08-12",
			status: "VERIFIED",
			recorded_by: "Mrs. Thandiwe Banda",
			receipt_number: "SA-2026-0388"
		},
		{
			id: id("pay-4"),
			user_id: u,
			school_id: sunrise,
			student_id: id("stu-mary"),
			parent_id: id("par-agnes"),
			amount: 28e4,
			method: "Airtel Money",
			reference: "AM-230011",
			payment_date: "2026-08-21",
			status: "VERIFIED",
			recorded_by: "Mrs. Thandiwe Banda",
			receipt_number: "SA-2026-0415"
		}
	]);
	await insMany(sql, "announcements", [
		{
			id: id("an-1"),
			user_id: u,
			school_id: sunrise,
			title: "Term 2 examinations begin 22 September",
			body: "The examination timetable is posted on the parent portal. Students should be on campus by 07:30. Calculators are permitted for Mathematics Paper 2 only.",
			audience: "ALL",
			class_id: null,
			created_at: "2026-09-10T08:00:00Z",
			author: "Mrs. Grace Mvula"
		},
		{
			id: id("an-2"),
			user_id: u,
			school_id: sunrise,
			title: "Fee deadline 30 September",
			body: "Outstanding Term 2 balances should be cleared before the examination period. Airtel Money, bank transfer and cash at the bursar’s office are accepted.",
			audience: "PARENTS",
			class_id: null,
			created_at: "2026-09-08T09:30:00Z",
			author: "Mrs. Thandiwe Banda"
		},
		{
			id: id("an-3"),
			user_id: u,
			school_id: sunrise,
			title: "Science club — Saturday 20 September",
			body: "Form 2 science club will host a practical for Standard 7. Volunteers from Form 2A please confirm with Mr. Mwale.",
			audience: "CLASS",
			class_id: id("cl-f2a"),
			created_at: "2026-09-12T14:00:00Z",
			author: "Mr. Yusuf Mwale"
		}
	]);
	await insMany(sql, "notifications", [
		{
			id: id("nt-1"),
			user_id: u,
			school_id: sunrise,
			title: "Term 1 results published",
			message: "Form 2A Term 1 results are now visible to verified parents.",
			channel: "IN_APP",
			event_type: "RESULT_PUBLISHED",
			created_at: "2026-04-06T08:01:00Z",
			is_read: true
		},
		{
			id: id("nt-2"),
			user_id: u,
			school_id: sunrise,
			title: "Absence recorded",
			message: "Tiyamike Gondwe was marked absent on 7 September.",
			channel: "SMS",
			event_type: "ABSENCE",
			created_at: "2026-09-07T08:40:00Z",
			is_read: false
		},
		{
			id: id("nt-3"),
			user_id: u,
			school_id: sunrise,
			title: "Fee reminder",
			message: "John Banda — MK 175,000 outstanding. Due 30 September.",
			channel: "PUSH",
			event_type: "FEE_DUE",
			created_at: "2026-09-14T07:00:00Z",
			is_read: false
		}
	]);
	await insMany(sql, "audit_logs", [
		{
			id: id("au-1"),
			user_id: u,
			school_id: sunrise,
			actor: "Mrs. Grace Mvula",
			action: "PUBLISH_RESULTS",
			entity_type: "result_submissions",
			entity_id: id("rs-t1-sub-math"),
			detail: "Published Form 2A Term 1 results for 4 students.",
			created_at: "2026-04-06T08:00:00Z"
		},
		{
			id: id("au-2"),
			user_id: u,
			school_id: sunrise,
			actor: "Mrs. Thandiwe Banda",
			action: "RECORD_PAYMENT",
			entity_type: "payments",
			entity_id: id("pay-1"),
			detail: "Verified Airtel Money MK 300,000 for John Banda.",
			created_at: "2026-08-20T11:12:00Z"
		},
		{
			id: id("au-3"),
			user_id: u,
			school_id: sunrise,
			actor: "Mr. James Banda",
			action: "SUBMIT_MARKS",
			entity_type: "result_submissions",
			entity_id: id("rs-t2-sub-math"),
			detail: "Submitted Form 2A Mathematics Term 2 marks.",
			created_at: "2026-08-01T10:00:00Z"
		},
		{
			id: id("au-4"),
			user_id: u,
			school_id: lakeview,
			actor: "Platform",
			action: "REGISTER_SCHOOL",
			entity_type: "schools",
			entity_id: lakeview,
			detail: "Lakeview Secondary registered. Awaiting activation payment.",
			created_at: "2026-09-01T09:00:00Z"
		}
	]);
	await insMany(sql, "calendar_events", [
		{
			id: id("ev-1"),
			user_id: u,
			school_id: sunrise,
			title: "Term 2 examinations",
			event_type: "EXAM",
			event_date: "2026-09-22"
		},
		{
			id: id("ev-2"),
			user_id: u,
			school_id: sunrise,
			title: "Fee deadline",
			event_type: "FEE",
			event_date: "2026-09-30"
		},
		{
			id: id("ev-3"),
			user_id: u,
			school_id: sunrise,
			title: "Parent meeting — Form 2",
			event_type: "MEETING",
			event_date: "2026-09-18"
		},
		{
			id: id("ev-4"),
			user_id: u,
			school_id: sunrise,
			title: "Closing day",
			event_type: "TERM",
			event_date: "2026-12-04"
		}
	]);
	await ins(sql, "nexus_workspaces", { user_id: u });
}
async function ensureWorkspace(sql, userId) {
	if ((await sql`
    select user_id from nexus_workspaces where user_id = ${userId}
  `).length) return;
	await seedWorkspace(sql, userId);
}
async function loadSnapshot(userId, schoolSlug) {
	const sql = await getSql();
	await ensureWorkspace(sql, userId);
	const schools = await sql`
    select * from schools where user_id = ${userId} order by name
  `;
	const school = schools.find((s) => s.slug === schoolSlug) ?? schools.find((s) => s.slug === "sunrise") ?? schools[0];
	if (!school) throw new Error("No school in workspace");
	const sid = school.id;
	const [staff, classes, subjects, assignments, students, parents, parentLinks, years, terms, assessments, scores, submissions, results, attendance, behaviour, fees, charges, payments, announcements, notifications, audit, events] = await Promise.all([
		sql`select * from staff where user_id = ${userId} and school_id = ${sid} order by full_name`,
		sql`select * from classes where user_id = ${userId} and school_id = ${sid} order by level_order desc, stream`,
		sql`select * from subjects where user_id = ${userId} and school_id = ${sid} order by name`,
		sql`select * from teacher_assignments where user_id = ${userId} and school_id = ${sid}`,
		sql`select * from students where user_id = ${userId} and school_id = ${sid} order by last_name, first_name`,
		sql`select * from parents where user_id = ${userId} and school_id = ${sid} order by full_name`,
		sql`select * from parent_students where user_id = ${userId}`,
		sql`select * from academic_years where user_id = ${userId} and school_id = ${sid}`,
		sql`select * from terms where user_id = ${userId} and school_id = ${sid} order by term_number`,
		sql`select * from assessments where user_id = ${userId} and school_id = ${sid} order by due_date`,
		sql`select * from assessment_scores where user_id = ${userId}`,
		sql`select * from result_submissions where user_id = ${userId} and school_id = ${sid}`,
		sql`select * from student_results where user_id = ${userId} and school_id = ${sid}`,
		sql`select * from attendance where user_id = ${userId} and school_id = ${sid} order by date desc`,
		sql`select * from behaviour_records where user_id = ${userId} and school_id = ${sid} order by date desc`,
		sql`select * from fee_structures where user_id = ${userId} and school_id = ${sid}`,
		sql`select * from student_charges where user_id = ${userId} and school_id = ${sid}`,
		sql`select * from payments where user_id = ${userId} and school_id = ${sid} order by payment_date desc`,
		sql`select * from announcements where user_id = ${userId} and school_id = ${sid} order by created_at desc`,
		sql`select * from notifications where user_id = ${userId} and school_id = ${sid} order by created_at desc`,
		sql`select * from audit_logs where user_id = ${userId} order by created_at desc limit 40`,
		sql`select * from calendar_events where user_id = ${userId} and school_id = ${sid} order by event_date`
	]);
	return {
		schools,
		school,
		staff,
		classes,
		subjects,
		assignments,
		students,
		parents,
		parentLinks,
		years,
		terms,
		assessments,
		scores,
		submissions,
		results,
		attendance,
		behaviour,
		fees,
		charges,
		payments,
		announcements,
		notifications,
		audit,
		events
	};
}
var getSnapshot_createServerFn_handler = createServerRpc({
	id: "c385edd4bc41943f2e24b620fe06d41496adb8b887d45af5daffa00e5a738740",
	name: "getSnapshot",
	filename: "src/lib/nexus/server.ts"
}, (opts) => getSnapshot.__executeServer(opts));
var getSnapshot = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data ?? {}).handler(getSnapshot_createServerFn_handler, async ({ context, data }) => {
	return loadSnapshot(context.userId, data.schoolSlug ?? "sunrise");
});
async function audit(userId, schoolId, actor, action, entityType, entityId, detail) {
	await (await getSql()).query(`insert into audit_logs (id, user_id, school_id, actor, action, entity_type, entity_id, detail)
     values ($1,$2,$3,$4,$5,$6,$7,$8)`, [
		nid(userId, `au-${Date.now()}-${Math.random().toString(36).slice(2, 6)}`),
		userId,
		schoolId,
		actor,
		action,
		entityType,
		entityId,
		detail
	]);
}
var markAttendance_createServerFn_handler = createServerRpc({
	id: "072372c95007d34d376d7dbba257268847c03f1a2ef8aa4b3fb5a226db881bcf",
	name: "markAttendance",
	filename: "src/lib/nexus/server.ts"
}, (opts) => markAttendance.__executeServer(opts));
var markAttendance = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(markAttendance_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureWorkspace(sql, context.userId);
	const existing = await sql`
      select id from attendance
      where user_id = ${context.userId} and student_id = ${data.studentId} and date = ${data.date}
    `;
	if (existing[0]) await sql.query(`update attendance set status = $1 where id = $2 and user_id = $3`, [
		data.status,
		existing[0].id,
		context.userId
	]);
	else {
		const stu = await sql`
        select school_id, class_id from students where id = ${data.studentId} and user_id = ${context.userId}
      `;
		if (!stu[0]) throw new Error("Student not found");
		await sql.query(`insert into attendance (id, user_id, school_id, student_id, class_id, date, status, recorded_by)
         values ($1,$2,$3,$4,$5,$6,$7,$8)`, [
			nid(context.userId, `att-${data.studentId}-${data.date}`),
			context.userId,
			stu[0].school_id,
			data.studentId,
			data.classId ?? stu[0].class_id,
			data.date,
			data.status,
			"Register"
		]);
	}
	return { ok: true };
});
var saveMarks_createServerFn_handler = createServerRpc({
	id: "dbb21d6699911a9feabbcfa8d82d73608224410357ead0e22f3b0aaf2cd06ae7",
	name: "saveMarks",
	filename: "src/lib/nexus/server.ts"
}, (opts) => saveMarks.__executeServer(opts));
var saveMarks = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(saveMarks_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const overall = Math.round(data.continuous * .4 + data.exam * .6);
	await sql.query(`update student_results
       set continuous_score = $1, exam_score = $2, overall_score = $3, grade = $4, teacher_comment = $5
       where id = $6 and user_id = $7 and status in ('DRAFT','RETURNED')`, [
		data.continuous,
		data.exam,
		overall,
		gradeFromScore(overall),
		data.comment ?? null,
		data.resultId,
		context.userId
	]);
	return {
		ok: true,
		overall,
		grade: gradeFromScore(overall)
	};
});
var NEXT = {
	DRAFT: "SUBMITTED",
	SUBMITTED: "UNDER_REVIEW",
	UNDER_REVIEW: "VERIFIED",
	VERIFIED: "APPROVED",
	APPROVED: "READY_TO_PUBLISH",
	READY_TO_PUBLISH: "PUBLISHED",
	RETURNED: "SUBMITTED"
};
var advanceSubmission_createServerFn_handler = createServerRpc({
	id: "0ce2e1d954c80d06feebef5f11b3db26b1469fda29c6ddafd79d49990807794c",
	name: "advanceSubmission",
	filename: "src/lib/nexus/server.ts"
}, (opts) => advanceSubmission.__executeServer(opts));
var advanceSubmission = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(advanceSubmission_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const sub = (await sql`
      select * from result_submissions where id = ${data.submissionId} and user_id = ${context.userId}
    `)[0];
	if (!sub) throw new Error("Submission not found");
	let next = sub.status;
	const now = (/* @__PURE__ */ new Date()).toISOString();
	if (data.action === "return") next = "RETURNED";
	else if (data.action === "submit") next = sub.status === "RETURNED" ? "SUBMITTED" : NEXT[sub.status] ?? sub.status;
	else if (data.action === "review") next = "UNDER_REVIEW";
	else if (data.action === "verify") next = "VERIFIED";
	else if (data.action === "approve") next = "APPROVED";
	else if (data.action === "ready") next = "READY_TO_PUBLISH";
	await sql.query(`update result_submissions
       set status = $1,
           submitted_at = coalesce(submitted_at, case when $1 in ('SUBMITTED','UNDER_REVIEW','VERIFIED','APPROVED','READY_TO_PUBLISH','PUBLISHED') then $2::timestamptz else null end),
           reviewed_at = case when $1 in ('VERIFIED','APPROVED','READY_TO_PUBLISH','PUBLISHED') then coalesce(reviewed_at, $2::timestamptz) else reviewed_at end,
           approved_at = case when $1 in ('APPROVED','READY_TO_PUBLISH','PUBLISHED') then coalesce(approved_at, $2::timestamptz) else approved_at end
       where id = $3 and user_id = $4`, [
		next,
		now,
		data.submissionId,
		context.userId
	]);
	await sql.query(`update student_results set status = $1
       where user_id = $2 and term_id = $3 and subject_id = $4
         and student_id in (select id from students where class_id = $5 and user_id = $2)`, [
		next,
		context.userId,
		sub.term_id,
		sub.subject_id,
		sub.class_id
	]);
	await audit(context.userId, sub.school_id, "Staff", data.action.toUpperCase() + "_MARKS", "result_submissions", sub.id, `Moved ${sub.id} from ${sub.status} to ${next}`);
	return {
		ok: true,
		status: next
	};
});
var publishResults_createServerFn_handler = createServerRpc({
	id: "37f372e2d11f1c60830bf0a5b67cee276cce0c737b8edfaa24e222a8e6218dd7",
	name: "publishResults",
	filename: "src/lib/nexus/server.ts"
}, (opts) => publishResults.__executeServer(opts));
var publishResults = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(publishResults_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const now = (/* @__PURE__ */ new Date()).toISOString();
	const subs = await sql`
      select * from result_submissions
      where user_id = ${context.userId} and class_id = ${data.classId} and term_id = ${data.termId}
    `;
	if (subs.length === 0) throw new Error("No submissions for this class and term");
	const blocked = subs.filter((s) => s.status !== "APPROVED" && s.status !== "READY_TO_PUBLISH" && s.status !== "PUBLISHED");
	if (blocked.length) throw new Error(`Cannot publish until every subject is approved. Still pending: ${blocked.length}.`);
	const students = await sql`
      select * from students where user_id = ${context.userId} and class_id = ${data.classId}
    `;
	const results = await sql`
      select * from student_results
      where user_id = ${context.userId} and term_id = ${data.termId}
        and student_id in (select id from students where class_id = ${data.classId} and user_id = ${context.userId})
    `;
	const averages = students.map((st) => {
		const mine = results.filter((r) => r.student_id === st.id);
		const avg = mine.length === 0 ? 0 : mine.reduce((a, r) => a + num(r.overall_score), 0) / mine.length;
		return {
			id: st.id,
			avg
		};
	});
	averages.sort((a, b) => b.avg - a.avg);
	for (let i = 0; i < averages.length; i++) await sql.query(`update student_results set status = 'PUBLISHED', position = $1
         where user_id = $2 and student_id = $3 and term_id = $4`, [
		i + 1,
		context.userId,
		averages[i].id,
		data.termId
	]);
	await sql.query(`update result_submissions
       set status = 'PUBLISHED', published_at = $1::timestamptz, published_by = $2
       where user_id = $3 and class_id = $4 and term_id = $5`, [
		now,
		data.actor ?? "Authorized publisher",
		context.userId,
		data.classId,
		data.termId
	]);
	const schoolId = subs[0].school_id;
	const cls = await sql`select * from classes where id = ${data.classId} and user_id = ${context.userId}`;
	const classLabel = cls[0] ? `${cls[0].name}${cls[0].stream ? " " + cls[0].stream : ""}` : "class";
	await sql.query(`insert into notifications (id, user_id, school_id, title, message, channel, event_type)
       values ($1,$2,$3,$4,$5,'IN_APP','RESULT_PUBLISHED'),
              ($6,$2,$3,$4,$5,'SMS','RESULT_PUBLISHED'),
              ($7,$2,$3,$4,$5,'PUSH','RESULT_PUBLISHED')`, [
		nid(context.userId, `nt-pub-${Date.now()}-a`),
		context.userId,
		schoolId,
		"Results published",
		`${classLabel} results are now visible to verified parents.`,
		nid(context.userId, `nt-pub-${Date.now()}-b`),
		nid(context.userId, `nt-pub-${Date.now()}-c`)
	]);
	await audit(context.userId, schoolId, data.actor ?? "Authorized publisher", "PUBLISH_RESULTS", "result_submissions", data.classId, `Published ${classLabel} results for ${students.length} students.`);
	return {
		ok: true,
		students: students.length
	};
});
var recordPayment_createServerFn_handler = createServerRpc({
	id: "7d09d37f1381d45d0eb3f4ef22c9551d25eb112443828c217b81fec0a66f1371",
	name: "recordPayment",
	filename: "src/lib/nexus/server.ts"
}, (opts) => recordPayment.__executeServer(opts));
var recordPayment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(recordPayment_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const ch = (await sql`
      select * from student_charges where id = ${data.chargeId} and user_id = ${context.userId}
    `)[0];
	if (!ch) throw new Error("Charge not found");
	const paid = num(ch.paid) + data.amount;
	const status = paid >= num(ch.amount) - .5 ? "PAID" : paid > 0 ? "PARTIAL" : "UNPAID";
	await sql.query(`update student_charges set paid = $1, status = $2 where id = $3 and user_id = $4`, [
		paid,
		status,
		ch.id,
		context.userId
	]);
	const receipt = `SA-2026-${String(4e3 + Math.floor(Math.random() * 900)).padStart(4, "0")}`;
	const payId = nid(context.userId, `pay-${Date.now()}`);
	await sql.query(`insert into payments (id, user_id, school_id, student_id, amount, method, reference, payment_date, status, recorded_by, receipt_number)
       values ($1,$2,$3,$4,$5,$6,$7,$8,'VERIFIED',$9,$10)`, [
		payId,
		context.userId,
		ch.school_id,
		ch.student_id,
		data.amount,
		data.method,
		data.reference ?? null,
		(/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
		"Bursar",
		receipt
	]);
	await audit(context.userId, ch.school_id, "Bursar", "RECORD_PAYMENT", "payments", payId, `Recorded ${data.method} ${data.amount} receipt ${receipt}.`);
	return {
		ok: true,
		receipt,
		status
	};
});
var addStudent_createServerFn_handler = createServerRpc({
	id: "0407fdfba4f95a3df11d63fdb15cf1da6be9308ef0e09ed1377d181efd708a18",
	name: "addStudent",
	filename: "src/lib/nexus/server.ts"
}, (opts) => addStudent.__executeServer(opts));
var addStudent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(addStudent_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	await ensureWorkspace(sql, context.userId);
	if (!(await sql`
      select * from schools where id = ${data.schoolId} and user_id = ${context.userId}
    `)[0]) throw new Error("School not found");
	const sid = nid(context.userId, `stu-${Date.now()}`);
	await sql.query(`insert into students (id, user_id, school_id, admission_number, first_name, last_name, gender, class_id, status, admission_date)
       values ($1,$2,$3,$4,$5,$6,$7,$8,'ACTIVE',$9)`, [
		sid,
		context.userId,
		data.schoolId,
		data.admissionNumber,
		data.firstName.trim(),
		data.lastName.trim(),
		data.gender,
		data.classId,
		(/* @__PURE__ */ new Date()).toISOString().slice(0, 10)
	]);
	await audit(context.userId, data.schoolId, "Registrar", "CREATE_STUDENT", "students", sid, `Enrolled ${data.firstName} ${data.lastName} (${data.admissionNumber}).`);
	return {
		ok: true,
		id: sid
	};
});
var addBehaviour_createServerFn_handler = createServerRpc({
	id: "5bd1803ab9e73bad979d394d03840c91076ff3fcb6040f6ae33b6e3fbc0387ac",
	name: "addBehaviour",
	filename: "src/lib/nexus/server.ts"
}, (opts) => addBehaviour.__executeServer(opts));
var addBehaviour = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(addBehaviour_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	const stu = await sql`
      select * from students where id = ${data.studentId} and user_id = ${context.userId}
    `;
	if (!stu[0]) throw new Error("Student not found");
	const bid = nid(context.userId, `beh-${Date.now()}`);
	await sql.query(`insert into behaviour_records (id, user_id, school_id, student_id, category, kind, severity, points, description, date, status, recorded_by)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'OPEN',$11)`, [
		bid,
		context.userId,
		stu[0].school_id,
		data.studentId,
		data.category,
		data.kind,
		Math.abs(data.points) >= 8 ? "High" : Math.abs(data.points) >= 4 ? "Medium" : "Low",
		data.points,
		data.description,
		(/* @__PURE__ */ new Date()).toISOString().slice(0, 10),
		"Staff"
	]);
	return { ok: true };
});
var addAnnouncement_createServerFn_handler = createServerRpc({
	id: "234cdd57fee2d97ea337ee177ec7ea2037009e3df9d7c680fe04d3ec72ed68e4",
	name: "addAnnouncement",
	filename: "src/lib/nexus/server.ts"
}, (opts) => addAnnouncement.__executeServer(opts));
var addAnnouncement = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(addAnnouncement_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (!(await sql`
      select id from schools where id = ${data.schoolId} and user_id = ${context.userId}
    `)[0]) throw new Error("School not found");
	await sql.query(`insert into announcements (id, user_id, school_id, title, body, audience, author)
       values ($1,$2,$3,$4,$5,$6,$7)`, [
		nid(context.userId, `an-${Date.now()}`),
		context.userId,
		data.schoolId,
		data.title.trim(),
		data.body.trim(),
		data.audience,
		"School office"
	]);
	return { ok: true };
});
var updateSchool_createServerFn_handler = createServerRpc({
	id: "832cb633e089ed1d040c4ebac904ecc0b81a8705dbca935535f987cf804f4645",
	name: "updateSchool",
	filename: "src/lib/nexus/server.ts"
}, (opts) => updateSchool.__executeServer(opts));
var updateSchool = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(updateSchool_createServerFn_handler, async ({ context, data }) => {
	const sql = await getSql();
	if (data.motto !== void 0) await sql.query(`update schools set motto = $1 where id = $2 and user_id = $3`, [
		data.motto,
		data.schoolId,
		context.userId
	]);
	if (data.phone !== void 0) await sql.query(`update schools set phone = $1 where id = $2 and user_id = $3`, [
		data.phone,
		data.schoolId,
		context.userId
	]);
	if (data.email !== void 0) await sql.query(`update schools set email = $1 where id = $2 and user_id = $3`, [
		data.email,
		data.schoolId,
		context.userId
	]);
	if (data.status !== void 0) await sql.query(`update schools set status = $1 where id = $2 and user_id = $3`, [
		data.status,
		data.schoolId,
		context.userId
	]);
	return { ok: true };
});
var activateSchool_createServerFn_handler = createServerRpc({
	id: "05946deb8c5e470cca58a14b07fbb1b0ce2a2e92825d3563e15a1daa28dfdca9",
	name: "activateSchool",
	filename: "src/lib/nexus/server.ts"
}, (opts) => activateSchool.__executeServer(opts));
var activateSchool = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(activateSchool_createServerFn_handler, async ({ context, data }) => {
	await (await getSql()).query(`update schools set status = 'ACTIVE' where id = $1 and user_id = $2`, [data.schoolId, context.userId]);
	await audit(context.userId, data.schoolId, "Platform owner", "ACTIVATE_SCHOOL", "schools", data.schoolId, "Activation payment verified. School set to ACTIVE.");
	return { ok: true };
});
//#endregion
export { activateSchool_createServerFn_handler, addAnnouncement_createServerFn_handler, addBehaviour_createServerFn_handler, addStudent_createServerFn_handler, advanceSubmission_createServerFn_handler, getSnapshot_createServerFn_handler, markAttendance_createServerFn_handler, publishResults_createServerFn_handler, recordPayment_createServerFn_handler, saveMarks_createServerFn_handler, updateSchool_createServerFn_handler };
