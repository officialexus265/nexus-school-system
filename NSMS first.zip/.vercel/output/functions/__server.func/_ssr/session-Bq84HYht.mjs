import { n as create, t as persist } from "../_libs/zustand.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/session-Bq84HYht.js
var PERSONAS = [
	{
		id: "owner",
		label: "School owner",
		blurb: "Full authority inside Sunrise Academy"
	},
	{
		id: "head",
		label: "Head teacher",
		blurb: "Academic oversight and result approval"
	},
	{
		id: "teacher",
		label: "Teacher · Mr. James Banda",
		blurb: "Mathematics, Forms 1–2"
	},
	{
		id: "exam",
		label: "Examination officer",
		blurb: "Marks, ranking and publication"
	},
	{
		id: "bursar",
		label: "Bursar",
		blurb: "Fees, receipts and outstanding balances"
	},
	{
		id: "parent",
		label: "Parent · Agnes Banda",
		blurb: "John (Form 2A) and Mary (Std 5)"
	},
	{
		id: "platform",
		label: "Platform owner",
		blurb: "Schools, billing and activation"
	}
];
var useNexusSession = create()(persist((set) => ({
	persona: "owner",
	schoolSlug: "sunrise",
	setPersona: (persona) => set({ persona }),
	setSchoolSlug: (schoolSlug) => set({ schoolSlug })
}), { name: "nexus-session" }));
//#endregion
export { useNexusSession as n, PERSONAS as t };
