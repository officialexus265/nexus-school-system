import { t as cva } from "../_libs/class-variance-authority+clsx.mjs";
import { t as cn } from "./utils-CZhKFE8j.mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/status-pill-BHrU-BqV.js
var import_jsx_runtime = require_jsx_runtime();
var badgeVariants = cva("inline-flex items-center rounded-full border px-2 py-0.5 text-[11px] font-medium tracking-wide uppercase", {
	variants: { variant: {
		default: "border-transparent bg-primary/12 text-primary",
		muted: "border-transparent bg-secondary text-muted-foreground",
		ok: "border-transparent bg-ok/12 text-ok",
		warn: "border-transparent bg-warn/12 text-warn",
		danger: "border-transparent bg-destructive/12 text-destructive",
		outline: "border-border text-foreground",
		ink: "border-transparent bg-ink text-foam"
	} },
	defaultVariants: { variant: "default" }
});
function Badge({ className, variant, ...props }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
		className: cn(badgeVariants({ variant }), className),
		...props
	});
}
var MAP = {
	ACTIVE: { variant: "ok" },
	VERIFIED: { variant: "ok" },
	PUBLISHED: { variant: "ok" },
	LOCKED: { variant: "ink" },
	PAID: { variant: "ok" },
	PRESENT: { variant: "ok" },
	CLOSED: { variant: "ok" },
	POSITIVE: { variant: "ok" },
	PENDING_PAYMENT: {
		variant: "warn",
		label: "Pending payment"
	},
	GRACE_PERIOD: {
		variant: "warn",
		label: "Grace period"
	},
	DORMANT: { variant: "muted" },
	PARTIAL: { variant: "warn" },
	LATE: { variant: "warn" },
	EXCUSED: { variant: "muted" },
	SUBMITTED: { variant: "default" },
	UNDER_REVIEW: {
		variant: "warn",
		label: "Under review"
	},
	APPROVED: { variant: "default" },
	READY_TO_PUBLISH: {
		variant: "default",
		label: "Ready"
	},
	DRAFT: { variant: "muted" },
	RETURNED: { variant: "danger" },
	SUSPENDED: { variant: "danger" },
	CANCELLED: { variant: "muted" },
	UNPAID: { variant: "danger" },
	ABSENT: { variant: "danger" },
	NEGATIVE: { variant: "danger" },
	OPEN: { variant: "warn" },
	MARKED: { variant: "ok" }
};
function StatusPill({ value }) {
	const meta = MAP[value] ?? { variant: "muted" };
	const label = meta.label ?? value.replaceAll("_", " ").toLowerCase();
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Badge, {
		variant: meta.variant,
		children: label
	});
}
//#endregion
export { StatusPill as t };
