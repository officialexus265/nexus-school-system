import { o as __toESM } from "../_runtime.mjs";
import { c as money, d as studentName, u as pct } from "./utils-CZhKFE8j.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { n as useNexusSession } from "./session-Bq84HYht.mjs";
import { m as useSnapshot, o as addStudent, p as useInvalidateSnapshot, t as PageHeader } from "./use-snapshot-DdgAICMx.mjs";
import { t as StatusPill } from "./status-pill-BHrU-BqV.mjs";
import { t as Skeleton } from "./skeleton-bYh8s0u6.mjs";
import { f as studentAttendance, i as classLabel, m as studentBalance, r as classById } from "./selectors-ZxoSqobI.mjs";
import { t as Button } from "./button-Bwm68GMl.mjs";
import { a as DialogHeader, i as DialogFooter, n as DialogContent, o as DialogTitle, r as DialogDescription, s as DialogTrigger, t as Dialog } from "./dialog-d-86_FpX.mjs";
import { t as Input } from "./input-4PW7zVuz.mjs";
import { t as Label } from "./label-KhZwICj-.mjs";
import { n as toast } from "../_libs/sonner.mjs";
import { a as SelectValue, i as SelectTrigger, n as SelectContent, r as SelectItem, t as Select } from "./select-BqmBkL4p.mjs";
import { t as Avatar } from "./avatar-kowjRr3_.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/students-B4mWH1W0.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
function StudentsPage() {
	const q = useSnapshot();
	const persona = useNexusSession((s) => s.persona);
	const dark = persona === "parent";
	if (q.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-64" });
	if (!q.data) return null;
	const snap = q.data;
	const students = persona === "teacher" ? snap.students.filter((s) => {
		const teacher = snap.staff.find((t) => t.full_name.includes("James Banda"));
		const ids = new Set(snap.assignments.filter((a) => a.staff_id === teacher?.id).map((a) => a.class_id));
		return s.class_id && ids.has(s.class_id);
	}) : snap.students;
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: dark ? "text-foam" : "",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: "People",
			title: "Students",
			description: "Records are archived, not deleted. Historical results and fees remain.",
			actions: persona === "parent" ? null : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EnrollDialog, {
				schoolId: snap.school.id,
				classes: snap.classes
			})
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "overflow-x-auto rounded-xl bg-card text-card-foreground shadow-[var(--shadow-border)]",
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("table", {
				className: "w-full min-w-[640px] text-left text-sm",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("thead", {
					className: "border-b border-border text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Student"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Admission"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Class"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Attend."
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Balance"
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("th", {
							className: "px-4 py-3 font-medium",
							children: "Status"
						})
					] })
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("tbody", { children: students.map((s) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("tr", {
					className: "border-b border-border last:border-0",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Link, {
								to: "/app/students/$studentId",
								params: { studentId: s.id },
								className: "flex items-center gap-2 hover:underline",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Avatar, { name: studentName(s) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: studentName(s) })]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 tabular-nums text-muted-foreground",
							children: s.admission_number
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: classLabel(classById(snap, s.class_id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 tabular-nums",
							children: pct(studentAttendance(snap, s.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3 tabular-nums",
							children: money(studentBalance(snap, s.id))
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("td", {
							className: "px-4 py-3",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: s.status })
						})
					]
				}, s.id)) })]
			})
		})]
	});
}
function EnrollDialog({ schoolId, classes }) {
	const invalidate = useInvalidateSnapshot();
	const [open, setOpen] = (0, import_react.useState)(false);
	const [firstName, setFirst] = (0, import_react.useState)("");
	const [lastName, setLast] = (0, import_react.useState)("");
	const [gender, setGender] = (0, import_react.useState)("F");
	const [classId, setClass] = (0, import_react.useState)(classes[0]?.id ?? "");
	const [admission, setAdm] = (0, import_react.useState)("SA-2026-");
	const [busy, setBusy] = (0, import_react.useState)(false);
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Dialog, {
		open,
		onOpenChange: setOpen,
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTrigger, {
			asChild: true,
			children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, { children: "Enrol student" })
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogContent, { children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)(DialogHeader, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogTitle, { children: "Enrol a student" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogDescription, { children: "Creates an ACTIVE record. Nothing is physically deleted later." })] }),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid gap-3 sm:grid-cols-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "First name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: firstName,
							onChange: (e) => setFirst(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Last name" }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: lastName,
							onChange: (e) => setLast(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Admission no." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Input, {
							value: admission,
							onChange: (e) => setAdm(e.target.value)
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Gender" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: gender,
							onValueChange: setGender,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(SelectContent, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "F",
								children: "Female"
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: "M",
								children: "Male"
							})] })]
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "space-y-1.5 sm:col-span-2",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Label, { children: "Class" }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Select, {
							value: classId,
							onValueChange: setClass,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectTrigger, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectValue, {}) }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectContent, { children: classes.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SelectItem, {
								value: c.id,
								children: c.stream ? `${c.name} ${c.stream}` : c.name
							}, c.id)) })]
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)(DialogFooter, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Button, {
				disabled: busy || !firstName.trim() || !lastName.trim(),
				onClick: async () => {
					setBusy(true);
					try {
						await addStudent({ data: {
							schoolId,
							firstName,
							lastName,
							gender,
							classId,
							admissionNumber: admission
						} });
						toast.success(`Enrolled ${firstName} ${lastName}`);
						setOpen(false);
						setFirst("");
						setLast("");
						await invalidate();
					} catch (e) {
						toast.error(e instanceof Error ? e.message : "Could not enrol");
					} finally {
						setBusy(false);
					}
				},
				children: busy ? "Saving…" : "Enrol"
			}) })
		] })]
	});
}
//#endregion
export { StudentsPage as component };
