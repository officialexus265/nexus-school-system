import { c as money, d as studentName, l as num, r as formatDate, u as pct } from "./utils-CZhKFE8j.mjs";
import { v as Link } from "../_libs/@tanstack/react-router+[...].mjs";
import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { m as useSnapshot, t as PageHeader } from "./use-snapshot-DdgAICMx.mjs";
import { t as StatusPill } from "./status-pill-BHrU-BqV.mjs";
import { t as Skeleton } from "./skeleton-bYh8s0u6.mjs";
import { f as studentAttendance, h as studentPosition, i as classLabel, l as publishedTerm, m as studentBalance, p as studentAverage, r as classById } from "./selectors-ZxoSqobI.mjs";
import { n as Route } from "./router-B0nzIRKr.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/students._studentId-B6R8HKdw.js
var import_jsx_runtime = require_jsx_runtime();
function StudentFile() {
	const { studentId } = Route.useParams();
	const q = useSnapshot();
	if (q.isPending) return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Skeleton, { className: "h-80" });
	if (!q.data) return null;
	const snap = q.data;
	const s = snap.students.find((x) => x.id === studentId);
	if (!s) return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", { children: "Student not found." }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Link, {
		to: "/app/students",
		className: "text-sm text-primary hover:underline",
		children: "Back"
	})] });
	const term = publishedTerm(snap);
	const avg = term ? studentAverage(snap, s.id, term.id, true) : null;
	const pos = term ? studentPosition(snap, s.id, term.id) : null;
	const parents = snap.parentLinks.filter((l) => l.student_id === s.id).map((l) => ({
		...l,
		parent: snap.parents.find((p) => p.id === l.parent_id)
	}));
	const charges = snap.charges.filter((c) => c.student_id === s.id);
	const results = term ? snap.results.filter((r) => r.student_id === s.id && r.term_id === term.id) : [];
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", { children: [
		/* @__PURE__ */ (0, import_jsx_runtime.jsx)(PageHeader, {
			kicker: s.admission_number,
			title: studentName(s),
			description: `${classLabel(classById(snap, s.class_id))} · ${s.gender === "F" ? "Female" : "Male"} · born ${formatDate(s.date_of_birth)}`
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "grid gap-3 sm:grid-cols-4",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: "Attendance",
					value: pct(studentAttendance(snap, s.id))
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: `${term?.name ?? "Term"} average`,
					value: avg != null ? pct(avg) : "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: "Position",
					value: pos ? String(pos) : "—"
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Mini, {
					label: "Balance",
					value: money(studentBalance(snap, s.id))
				})
			]
		}),
		/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "mt-6 grid gap-4 lg:grid-cols-2",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Parents"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 space-y-2",
						children: parents.map((p) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", { children: [
								p.parent?.full_name,
								" · ",
								p.relationship
							] }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: p.parent?.verification_status ?? "PENDING" })]
						}, p.id))
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)]",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Published subjects"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("ul", {
						className: "mt-3 space-y-2",
						children: [results.map((r) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: snap.subjects.find((x) => x.id === r.subject_id)?.name }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "tabular-nums",
								children: [
									num(r.overall_score),
									" ",
									r.grade
								]
							})]
						}, r.id)), results.length === 0 ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "text-sm text-muted-foreground",
							children: "Nothing published yet."
						}) : null]
					})]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
					className: "rounded-xl bg-card p-5 shadow-[var(--shadow-border)] lg:col-span-2",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "font-display text-xl",
						children: "Charges"
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "mt-3 divide-y divide-border",
						children: charges.map((c) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center justify-between py-2 text-sm",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: c.description }), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
								className: "flex items-center gap-3",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
									className: "tabular-nums",
									children: [
										money(c.paid),
										" / ",
										money(c.amount)
									]
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(StatusPill, { value: c.status })]
							})]
						}, c.id))
					})]
				})
			]
		})
	] });
}
function Mini({ label, value }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)]",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "text-[11px] uppercase tracking-[0.12em] text-muted-foreground",
			children: label
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
			className: "mt-1 font-display text-2xl tabular-nums",
			children: value
		})]
	});
}
//#endregion
export { StudentFile as component };
