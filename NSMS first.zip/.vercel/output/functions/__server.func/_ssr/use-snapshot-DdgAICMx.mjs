import { s as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { a as getServerFnById, i as TSS_SERVER_FUNCTION, r as createServerFn } from "./ssr.mjs";
import { t as authMiddleware } from "./middleware-DObhFC7t.mjs";
import { n as useNexusSession } from "./session-Bq84HYht.mjs";
import { r as useQueryClient, t as useQuery } from "../_libs/tanstack__react-query.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/use-snapshot-DdgAICMx.js
var import_jsx_runtime = require_jsx_runtime();
function PageHeader({ kicker, title, description, actions }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "mb-6 flex flex-col gap-3 sm:mb-8 sm:flex-row sm:items-end sm:justify-between",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "min-w-0",
			children: [
				kicker ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mb-1 text-[11px] font-medium uppercase tracking-[0.16em] text-muted-foreground",
					children: kicker
				}) : null,
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
					className: "font-display text-3xl font-medium tracking-tight text-foreground md:text-4xl",
					children: title
				}),
				description ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
					className: "mt-1.5 max-w-2xl text-sm text-muted-foreground",
					children: description
				}) : null
			]
		}), actions ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
			className: "flex flex-wrap items-center gap-2",
			children: actions
		}) : null]
	});
}
function StatCard({ label, value, hint }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "rounded-xl bg-card p-4 shadow-[var(--shadow-border)] sm:p-5",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "text-[11px] font-medium uppercase tracking-[0.14em] text-muted-foreground",
				children: label
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-2 font-display text-3xl font-medium tabular-nums tracking-tight text-foreground",
				children: value
			}),
			hint ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
				className: "mt-1 text-xs text-muted-foreground",
				children: hint
			}) : null
		]
	});
}
var createSsrRpc = (functionId) => {
	const url = "/_serverFn/" + functionId;
	const serverFnMeta = { id: functionId };
	const fn = async (...args) => {
		return (await getServerFnById(functionId, { origin: "server" }))(...args);
	};
	return Object.assign(fn, {
		url,
		serverFnMeta,
		[TSS_SERVER_FUNCTION]: true
	});
};
var getSnapshot = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data ?? {}).handler(createSsrRpc("c385edd4bc41943f2e24b620fe06d41496adb8b887d45af5daffa00e5a738740"));
var markAttendance = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("072372c95007d34d376d7dbba257268847c03f1a2ef8aa4b3fb5a226db881bcf"));
var saveMarks = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("dbb21d6699911a9feabbcfa8d82d73608224410357ead0e22f3b0aaf2cd06ae7"));
var advanceSubmission = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("0ce2e1d954c80d06feebef5f11b3db26b1469fda29c6ddafd79d49990807794c"));
var publishResults = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("37f372e2d11f1c60830bf0a5b67cee276cce0c737b8edfaa24e222a8e6218dd7"));
var recordPayment = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("7d09d37f1381d45d0eb3f4ef22c9551d25eb112443828c217b81fec0a66f1371"));
var addStudent = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("0407fdfba4f95a3df11d63fdb15cf1da6be9308ef0e09ed1377d181efd708a18"));
var addBehaviour = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("5bd1803ab9e73bad979d394d03840c91076ff3fcb6040f6ae33b6e3fbc0387ac"));
var addAnnouncement = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("234cdd57fee2d97ea337ee177ec7ea2037009e3df9d7c680fe04d3ec72ed68e4"));
var updateSchool = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("832cb633e089ed1d040c4ebac904ecc0b81a8705dbca935535f987cf804f4645"));
var activateSchool = createServerFn({ method: "POST" }).middleware([authMiddleware]).validator((data) => data).handler(createSsrRpc("05946deb8c5e470cca58a14b07fbb1b0ce2a2e92825d3563e15a1daa28dfdca9"));
var SNAPSHOT_KEY = ["nexus-snapshot"];
function useSnapshot() {
	const schoolSlug = useNexusSession((s) => s.schoolSlug);
	return useQuery({
		queryKey: [...SNAPSHOT_KEY, schoolSlug],
		queryFn: () => getSnapshot({ data: { schoolSlug } })
	});
}
function useInvalidateSnapshot() {
	const qc = useQueryClient();
	return () => qc.invalidateQueries({ queryKey: SNAPSHOT_KEY });
}
//#endregion
export { addBehaviour as a, markAttendance as c, saveMarks as d, updateSchool as f, addAnnouncement as i, publishResults as l, useSnapshot as m, StatCard as n, addStudent as o, useInvalidateSnapshot as p, activateSchool as r, advanceSubmission as s, PageHeader as t, recordPayment as u };
