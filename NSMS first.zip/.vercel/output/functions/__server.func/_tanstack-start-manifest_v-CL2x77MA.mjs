//#region node_modules/.nitro/vite/services/ssr/assets/_tanstack-start-manifest_v-CL2x77MA.js
var tsrStartManifest = () => ({ routes: {
	__root__: {
		filePath: "/workspace/src/routes/__root.tsx",
		children: [
			"/",
			"/app",
			"/login",
			"/api/auth/$"
		],
		preloads: [
			"/assets/index-DnJOgok8.js",
			"/assets/react-SIfiwpqq.js",
			"/assets/react-dom-x9LNwWQc.js",
			"/assets/preload-helper-CeVzun_F.js",
			"/assets/utils-BmBCOjLJ.js",
			"/assets/link-Bal1O0KV.js",
			"/assets/not-found-DIgawKw1.js",
			"/assets/useMatch-DtD3UBxh.js",
			"/assets/dist-eWugMcqx.js",
			"/assets/dist-pIHewt2b.js",
			"/assets/dist-qG4LP_ny.js",
			"/assets/dist-BiUbZKix.js"
		],
		scripts: [{ attrs: {
			type: "module",
			async: !0,
			src: "/assets/index-DnJOgok8.js"
		} }]
	},
	"/": {
		filePath: "/workspace/src/routes/index.tsx",
		children: void 0,
		preloads: [
			"/assets/routes-D9mWn7TA.js",
			"/assets/button-C_5R2l2f.js",
			"/assets/use-current-user-DXzg9kKP.js",
			"/assets/gates-BOImFizg.js"
		]
	},
	"/app": {
		filePath: "/workspace/src/routes/app/route.tsx",
		children: [
			"/app/academics",
			"/app/announcements",
			"/app/attendance",
			"/app/behaviour",
			"/app/finance",
			"/app/people",
			"/app/platform",
			"/app/results",
			"/app/settings",
			"/app/students",
			"/app/"
		],
		preloads: [
			"/assets/route-D4KC9eap.js",
			"/assets/check-BgT7j_CG.js",
			"/assets/dist-CZ0F6Yqe.js",
			"/assets/dist-DQRBEj7B.js",
			"/assets/skeleton-DGzN8T2Y.js",
			"/assets/session-C0ocFi8m.js",
			"/assets/button-C_5R2l2f.js",
			"/assets/dist-8kDqmQE-.js",
			"/assets/avatar-BcITLFOd.js",
			"/assets/dist-Bes2cHam.js",
			"/assets/use-current-user-DXzg9kKP.js",
			"/assets/gates-BOImFizg.js"
		]
	},
	"/login": {
		filePath: "/workspace/src/routes/login.tsx",
		children: void 0,
		preloads: [
			"/assets/login-DSqp35XB.js",
			"/assets/client-C85fcJ4s.js",
			"/assets/skeleton-DGzN8T2Y.js",
			"/assets/button-C_5R2l2f.js",
			"/assets/use-current-user-DXzg9kKP.js"
		]
	},
	"/app/academics": {
		filePath: "/workspace/src/routes/app/academics.tsx",
		children: void 0,
		preloads: [
			"/assets/academics-B2oW_BQO.js",
			"/assets/use-snapshot-OORjZjZy.js",
			"/assets/status-pill-Do2aruRR.js",
			"/assets/selectors-D15aSMm6.js"
		]
	},
	"/app/announcements": {
		filePath: "/workspace/src/routes/app/announcements.tsx",
		children: void 0,
		preloads: [
			"/assets/announcements-BCjJAI4B.js",
			"/assets/use-snapshot-OORjZjZy.js",
			"/assets/dialog-CmvcgQJC.js",
			"/assets/input-DOMTaxxV.js",
			"/assets/label-CyoU48ek.js",
			"/assets/textarea-Dz1cGR8G.js"
		]
	},
	"/app/attendance": {
		filePath: "/workspace/src/routes/app/attendance.tsx",
		children: void 0,
		preloads: [
			"/assets/attendance-DRdynLAv.js",
			"/assets/use-snapshot-OORjZjZy.js",
			"/assets/status-pill-Do2aruRR.js",
			"/assets/selectors-D15aSMm6.js"
		]
	},
	"/app/behaviour": {
		filePath: "/workspace/src/routes/app/behaviour.tsx",
		children: void 0,
		preloads: [
			"/assets/behaviour-VzKfohJY.js",
			"/assets/use-snapshot-OORjZjZy.js",
			"/assets/select-BpgMmzUS.js",
			"/assets/status-pill-Do2aruRR.js",
			"/assets/selectors-D15aSMm6.js",
			"/assets/dialog-CmvcgQJC.js",
			"/assets/input-DOMTaxxV.js",
			"/assets/label-CyoU48ek.js",
			"/assets/textarea-Dz1cGR8G.js"
		]
	},
	"/app/finance": {
		filePath: "/workspace/src/routes/app/finance.tsx",
		children: void 0,
		preloads: [
			"/assets/finance-YjOadb5t.js",
			"/assets/use-snapshot-OORjZjZy.js",
			"/assets/select-BpgMmzUS.js",
			"/assets/status-pill-Do2aruRR.js",
			"/assets/selectors-D15aSMm6.js",
			"/assets/dialog-CmvcgQJC.js",
			"/assets/input-DOMTaxxV.js",
			"/assets/label-CyoU48ek.js"
		]
	},
	"/app/people": {
		filePath: "/workspace/src/routes/app/people.tsx",
		children: void 0,
		preloads: [
			"/assets/people-CY3ofdst.js",
			"/assets/use-snapshot-OORjZjZy.js",
			"/assets/status-pill-Do2aruRR.js",
			"/assets/selectors-D15aSMm6.js"
		]
	},
	"/app/platform": {
		filePath: "/workspace/src/routes/app/platform.tsx",
		children: void 0,
		preloads: [
			"/assets/platform-LeQaCVlc.js",
			"/assets/use-snapshot-OORjZjZy.js",
			"/assets/status-pill-Do2aruRR.js"
		]
	},
	"/app/results": {
		filePath: "/workspace/src/routes/app/results.tsx",
		children: void 0,
		preloads: [
			"/assets/results-DHMs-iE_.js",
			"/assets/use-snapshot-OORjZjZy.js",
			"/assets/status-pill-Do2aruRR.js",
			"/assets/selectors-D15aSMm6.js",
			"/assets/dialog-CmvcgQJC.js",
			"/assets/input-DOMTaxxV.js"
		]
	},
	"/app/settings": {
		filePath: "/workspace/src/routes/app/settings.tsx",
		children: void 0,
		preloads: [
			"/assets/settings-CJ31DNY3.js",
			"/assets/use-snapshot-OORjZjZy.js",
			"/assets/status-pill-Do2aruRR.js",
			"/assets/input-DOMTaxxV.js",
			"/assets/label-CyoU48ek.js"
		]
	},
	"/app/students": {
		filePath: "/workspace/src/routes/app/students.tsx",
		children: ["/app/students/$studentId"],
		preloads: [
			"/assets/students-7ORGJmIs.js",
			"/assets/use-snapshot-OORjZjZy.js",
			"/assets/select-BpgMmzUS.js",
			"/assets/status-pill-Do2aruRR.js",
			"/assets/selectors-D15aSMm6.js",
			"/assets/dialog-CmvcgQJC.js",
			"/assets/input-DOMTaxxV.js",
			"/assets/label-CyoU48ek.js"
		]
	},
	"/app/": {
		filePath: "/workspace/src/routes/app/index.tsx",
		children: void 0,
		preloads: [
			"/assets/app-CMyHRFCa.js",
			"/assets/use-snapshot-OORjZjZy.js",
			"/assets/status-pill-Do2aruRR.js",
			"/assets/selectors-D15aSMm6.js"
		]
	},
	"/app/students/$studentId": {
		filePath: "/workspace/src/routes/app/students.$studentId.tsx",
		children: void 0,
		preloads: ["/assets/students._studentId-hMjvVZUq.js"]
	}
} });
//#endregion
export { tsrStartManifest };
