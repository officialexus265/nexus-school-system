import { createFileRoute, Link, Navigate } from "@tanstack/react-router";
import { GROK_PROVIDERS, authEnabled, signIn } from "@/lib/auth/client";
import { useCurrentUserState } from "@/lib/auth/use-current-user";
import { NexusMark } from "@/components/brand/mark";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";

export const Route = createFileRoute("/login")({ component: Login });

function Login() {
  const { user, isPending } = useCurrentUserState();
  if (isPending) {
    return (
      <main className="grid min-h-dvh place-items-center bg-ink">
        <Skeleton className="h-48 w-80 bg-ink-3" />
      </main>
    );
  }
  if (user) return <Navigate to="/app" />;

  return (
    <main className="relative min-h-dvh bg-ink text-foam">
      <div className="ledger-grid pointer-events-none absolute inset-0 opacity-40" />
      <div className="relative mx-auto flex min-h-dvh max-w-md flex-col justify-center px-6 py-16">
        <Link to="/" className="mb-10 flex items-center gap-2 text-foam">
          <NexusMark className="text-foam" />
          <span className="font-display text-2xl font-medium tracking-tight">NEXUS</span>
        </Link>
        <h1 className="font-display text-4xl font-medium tracking-tight">Enter the desk.</h1>
        <p className="mt-3 text-sm leading-relaxed text-mist">
          School owners, teachers and platform operators sign in here. Parents use the same
          workspace after you switch role inside.
        </p>
        <div className="mt-8 space-y-3">
          {authEnabled ? (
            GROK_PROVIDERS.map((p) => (
              <Button
                key={p.providerId}
                type="button"
                variant="secondary"
                className="h-11 w-full bg-foam text-ink hover:bg-foam/90"
                onClick={() => signIn(p.providerId, { callbackURL: "/app" })}
              >
                Continue with {p.label}
              </Button>
            ))
          ) : (
            <p className="text-sm text-mist">Sign-in is disabled.</p>
          )}
        </div>
        <p className="mt-8 text-xs text-mist">
          Opening the workspace provisions Sunrise Academy with live Term 2 records for this
          account only.
        </p>
      </div>
    </main>
  );
}
